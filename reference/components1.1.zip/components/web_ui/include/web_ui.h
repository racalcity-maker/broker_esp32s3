#pragma once

#include "esp_err.h"
#include "mqtt_core.h"
#include "audio_player.h"

esp_err_t web_ui_init(void);
esp_err_t web_ui_start(void);
