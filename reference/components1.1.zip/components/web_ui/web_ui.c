#include "web_ui.h"

#include <string.h>
#include <strings.h>
#include <stdio.h>
#include <dirent.h>
#include <stdint.h>
#include <ctype.h>
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"
#include "esp_log.h"
#include "esp_http_server.h"
#include "esp_netif.h"
#include "esp_wifi.h"
#include "lwip/ip4_addr.h"
#include "event_bus.h"
#include "config_store.h"
#include "esp_check.h"
#include "esp_timer.h"
#include "esp_system.h"
#include "esp_heap_caps.h"
#include "esp_vfs_fat.h"
#include "network.h"
#include "audio_player.h"
#include <sys/stat.h>
#include "nvs.h"
#include "mqtt_core.h"

static const char *TAG = "web_ui";
static httpd_handle_t s_server = NULL;
static SemaphoreHandle_t s_scan_mutex = NULL;
static SemaphoreHandle_t s_pic_mutex = NULL;
static SemaphoreHandle_t s_laser_mutex = NULL;


#define PIC_DEVICES 5
#define PIC_UIDS    10
typedef struct {
    char uids[PIC_UIDS][16];
    uint8_t count;
    char last_uid[16];
} pic_device_cfg_t;

typedef struct {
    pic_device_cfg_t dev[PIC_DEVICES];
    char track_ok[96];
    char track_fail[96];
} pic_cfg_t;

typedef struct {
    char track_hold[96];
    char track_relay[96];
    int hold_seconds;
    bool cumulative;
    bool enabled;
} laser_cfg_t;

static pic_cfg_t s_pic_cfg;
static void pic_handle_scan(int idx, const char *uid);
static void pic_handle_check(void);

static laser_cfg_t s_laser_cfg;

typedef struct {
    char laser_dir[96];
    char sarcastic_dir[96];
    char broken_dir[96];
} robot_cfg_t;

static robot_cfg_t s_robot_cfg;

#define ROBOT_PRESET_COUNT 8
#define ROBOT_NAME_LEN 48
typedef struct {
    char names[ROBOT_PRESET_COUNT][ROBOT_NAME_LEN];
} robot_presets_t;

static robot_presets_t s_robot_presets;

// laser runtime state
static bool s_laser_present = false;
static bool s_laser_playing = false;
static bool s_relay_triggered = false;
static bool s_hold_completed = false;
static int64_t s_last_heartbeat_ms = 0;
static int64_t s_hold_total_ms = 0;
static int64_t s_hold_streak_ms = 0;
static int64_t s_robot_last_ms = 0;
static esp_timer_handle_t s_laser_timeout = NULL;

#define LASER_TIMEOUT_US (2000000) // consider laser off if no heartbeat for 2s
#define LASER_ROBOT_INTERVAL_MS (10000)
#define LASER_ROBOT_MAX_TRACKS 32

static char s_robot_tracks[LASER_ROBOT_MAX_TRACKS][96];
static int s_robot_track_count = 0;
static bool s_robot_scanned = false;

static void pic_lock(void)
{
    if (s_pic_mutex) {
        xSemaphoreTake(s_pic_mutex, portMAX_DELAY);
    }
}

static void pic_unlock(void)
{
    if (s_pic_mutex) {
        xSemaphoreGive(s_pic_mutex);
    }
}

static void laser_lock(void)
{
    if (s_laser_mutex) {
        xSemaphoreTake(s_laser_mutex, portMAX_DELAY);
    }
}

static void laser_unlock(void)
{
    if (s_laser_mutex) {
        xSemaphoreGive(s_laser_mutex);
    }
}

static void parse_uids_csv(const char *csv, char out[][16], uint8_t *out_count)
{
    if (!csv || !out || !out_count) return;
    uint8_t cnt = 0;
    const char *p = csv;
    while (*p && cnt < PIC_UIDS) {
        while (*p == ',' || *p == ' ') p++;
        if (*p == 0) break;
        char buf[16] = {0};
        int i = 0;
        while (*p && *p != ',' && i < (int)sizeof(buf) - 1) {
            buf[i++] = *p++;
        }
        strncpy(out[cnt], buf, sizeof(out[cnt]) - 1);
        out[cnt][sizeof(out[cnt]) - 1] = 0;
        cnt++;
        if (*p == ',') p++;
    }
    *out_count = cnt;
}

static void url_decode(char *out, size_t out_len, const char *in)
{
    size_t o = 0;
    for (size_t i = 0; in[i] && o + 1 < out_len; ++i) {
        if (in[i] == '%' && isxdigit((unsigned char)in[i + 1]) && isxdigit((unsigned char)in[i + 2])) {
            char hex[3] = {in[i + 1], in[i + 2], 0};
            out[o++] = (char)strtol(hex, NULL, 16);
            i += 2;
        } else if (in[i] == '+') {
            out[o++] = ' ';
        } else {
            out[o++] = in[i];
        }
    }
    out[o] = 0;
}

static void pic_load_defaults(pic_cfg_t *cfg)
{
    memset(cfg, 0, sizeof(*cfg));
}

static esp_err_t pic_load(pic_cfg_t *cfg)
{
    if (!cfg) return ESP_ERR_INVALID_ARG;
    nvs_handle_t h;
    esp_err_t err = nvs_open("piccfg", NVS_READONLY, &h);
    if (err != ESP_OK) {
        ESP_LOGW(TAG, "pic load: no nvs namespace (%s)", esp_err_to_name(err));
        pic_load_defaults(cfg);
        return err;
    }
    size_t sz = sizeof(*cfg);
    err = nvs_get_blob(h, "cfg", cfg, &sz);
    nvs_close(h);
    if (err != ESP_OK || sz != sizeof(*cfg)) {
        ESP_LOGW(TAG, "pic load: get_blob failed %s sz=%u expected=%u", esp_err_to_name(err), (unsigned)sz, (unsigned)sizeof(*cfg));
        pic_load_defaults(cfg);
        return err;
    }
    return ESP_OK;
}

static esp_err_t pic_save(const pic_cfg_t *cfg)
{
    if (!cfg) return ESP_ERR_INVALID_ARG;
    nvs_handle_t h;
    esp_err_t err = nvs_open("piccfg", NVS_READWRITE, &h);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "pic save: open failed %s", esp_err_to_name(err));
        return err;
    }
    err = nvs_set_blob(h, "cfg", cfg, sizeof(*cfg));
    if (err == ESP_OK) {
        err = nvs_commit(h);
    } else {
        ESP_LOGE(TAG, "pic save: set_blob failed %s", esp_err_to_name(err));
    }
    nvs_close(h);
    // saved
    return err;
}

static void laser_load_defaults(laser_cfg_t *cfg)
{
    if (!cfg) return;
    memset(cfg, 0, sizeof(*cfg));
    cfg->hold_seconds = 20;
    cfg->cumulative = true;
    cfg->enabled = true;
}

static esp_err_t laser_load(laser_cfg_t *cfg)
{
    if (!cfg) return ESP_ERR_INVALID_ARG;
    nvs_handle_t h;
    esp_err_t err = nvs_open("lasercfg", NVS_READONLY, &h);
    if (err != ESP_OK) {
        ESP_LOGW(TAG, "laser load: no nvs namespace (%s)", esp_err_to_name(err));
         laser_load_defaults(cfg);
         return err;
     }
    size_t sz = sizeof(*cfg);
    err = nvs_get_blob(h, "cfg", cfg, &sz);
    nvs_close(h);
    if (err != ESP_OK || sz != sizeof(*cfg)) {
        ESP_LOGW(TAG, "laser load: get_blob failed %s sz=%u expected=%u", esp_err_to_name(err), (unsigned)sz, (unsigned)sizeof(*cfg));
        laser_load_defaults(cfg);
        return err;
    }
    return ESP_OK;
}

static esp_err_t laser_save(const laser_cfg_t *cfg)
{
    if (!cfg) return ESP_ERR_INVALID_ARG;
    nvs_handle_t h;
    esp_err_t err = nvs_open("lasercfg", NVS_READWRITE, &h);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "laser save: open failed %s", esp_err_to_name(err));
        return err;
    }
    err = nvs_set_blob(h, "cfg", cfg, sizeof(*cfg));
    if (err == ESP_OK) {
        err = nvs_commit(h);
    } else {
        ESP_LOGE(TAG, "laser save: set_blob failed %s", esp_err_to_name(err));
    }
    nvs_close(h);
    // saved
    return err;
}

static void robot_load_defaults(robot_cfg_t *cfg)
{
    if (!cfg) return;
    memset(cfg, 0, sizeof(*cfg));
    strncpy(cfg->laser_dir, "/sdcard/laser", sizeof(cfg->laser_dir) - 1);
}

static esp_err_t robot_load(robot_cfg_t *cfg)
{
    if (!cfg) return ESP_ERR_INVALID_ARG;
    nvs_handle_t h;
    esp_err_t err = nvs_open("robotcfg", NVS_READONLY, &h);
    if (err != ESP_OK) {
        robot_load_defaults(cfg);
        return err;
    }
    size_t sz = sizeof(*cfg);
    err = nvs_get_blob(h, "cfg", cfg, &sz);
    nvs_close(h);
    if (err != ESP_OK || sz != sizeof(*cfg)) {
        robot_load_defaults(cfg);
        return err;
    }
    return ESP_OK;
}

static esp_err_t robot_save(const robot_cfg_t *cfg)
{
    if (!cfg) return ESP_ERR_INVALID_ARG;
    nvs_handle_t h;
    esp_err_t err = nvs_open("robotcfg", NVS_READWRITE, &h);
    if (err != ESP_OK) {
        return err;
    }
    err = nvs_set_blob(h, "cfg", cfg, sizeof(*cfg));
    if (err == ESP_OK) {
        err = nvs_commit(h);
    }
    nvs_close(h);
    return err;
}

static void robot_presets_default(robot_presets_t *p)
{
    if (!p) return;
    memset(p, 0, sizeof(*p));
}

static esp_err_t robot_presets_load(robot_presets_t *p)
{
    if (!p) return ESP_ERR_INVALID_ARG;
    nvs_handle_t h;
    esp_err_t err = nvs_open("robotpreset", NVS_READONLY, &h);
    if (err != ESP_OK) {
        robot_presets_default(p);
        return err;
    }
    size_t sz = sizeof(*p);
    err = nvs_get_blob(h, "slots", p, &sz);
    nvs_close(h);
    if (err != ESP_OK || sz != sizeof(*p)) {
        robot_presets_default(p);
        return err;
    }
    return ESP_OK;
}

static esp_err_t robot_presets_save(const robot_presets_t *p)
{
    if (!p) return ESP_ERR_INVALID_ARG;
    nvs_handle_t h;
    esp_err_t err = nvs_open("robotpreset", NVS_READWRITE, &h);
    if (err != ESP_OK) {
        return err;
    }
    err = nvs_set_blob(h, "slots", p, sizeof(*p));
    if (err == ESP_OK) {
        err = nvs_commit(h);
    }
    nvs_close(h);
    return err;
}

static int64_t now_ms(void)
{
    return esp_timer_get_time() / 1000;
}

static int64_t s_last_result_ms = 0;
static bool    s_last_result_valid = false;
static bool    s_last_result_ok = false;

static bool is_audio_ext(const char *ext)
{
    if (!ext) return false;
    return strcasecmp(ext, ".wav") == 0 || strcasecmp(ext, ".mp3") == 0 || strcasecmp(ext, ".ogg") == 0;
}

static void laser_scan_robot_tracks(void)
{
    s_robot_track_count = 0;
    s_robot_scanned = true;
    if (audio_player_mount_sd() != ESP_OK) {
        return;
    }
    DIR *d = opendir("/sdcard/laser");
    if (!d) {
        return;
    }
    struct dirent *ent;
    while ((ent = readdir(d)) != NULL && s_robot_track_count < LASER_ROBOT_MAX_TRACKS) {
        const char *n = ent->d_name;
        size_t nlen = strlen(n);
        if (nlen < 4) continue;
        const char *ext = n + nlen - 4;
        if (!is_audio_ext(ext)) continue;
        const size_t prefix_len = strlen("/sdcard/laser/");
        const size_t buf_sz = sizeof(s_robot_tracks[s_robot_track_count]);
        if (buf_sz <= prefix_len + 1) {
            continue;
        }
        size_t max_name = buf_sz - prefix_len - 1;
        size_t copy_len = strnlen(n, max_name);
        snprintf(s_robot_tracks[s_robot_track_count], buf_sz, "/sdcard/laser/%.*s", (int)copy_len, n);
        s_robot_track_count++;
    }
    closedir(d);
}

static const char *laser_random_robot_track(void)
{
    if (!s_robot_scanned) {
        laser_scan_robot_tracks();
    }
    if (s_robot_track_count == 0) {
        return NULL;
    }
    uint32_t r = esp_random();
    int idx = (int)(r % s_robot_track_count);
    return s_robot_tracks[idx];
}

static void laser_stop_audio(void)
{
    if (!s_laser_playing) return;
    audio_player_pause();
}

static void laser_start_audio(void)
{
    if (!s_laser_cfg.enabled) return;
    if (s_hold_completed) return;
    if (s_laser_playing) {
        audio_player_resume();
        return;
    }
    if (s_laser_cfg.track_hold[0]) {
        audio_player_play(s_laser_cfg.track_hold);
        s_laser_playing = true;
    }
}

static void laser_trigger_relay(void)
{
    s_relay_triggered = true;
    s_hold_completed = true;
    ESP_LOGI(TAG, "relay trigger: publishing relay/relayOn and robot/laser/relayOn.mp3");
    mqtt_core_publish("relay/relayOn", "on");
    mqtt_core_publish("robot/laser/relayOn.mp3", "/sdcard/laser/relayOn.mp3");
    // Stop hold track before playing relay track to avoid immediate stop of the new one.
    audio_player_stop();
    s_laser_playing = false;
    if (s_laser_cfg.track_relay[0]) {
        audio_player_play(s_laser_cfg.track_relay);
    }
}

static void laser_maybe_send_robot(int64_t now)
{
    if (!s_laser_cfg.enabled) return;
    if (!s_laser_present) return;
    if (now - s_robot_last_ms < LASER_ROBOT_INTERVAL_MS) return;
    const char *path = laser_random_robot_track();
    if (!path) return;
    ESP_LOGI(TAG, "robot speak: publishing robot/laser/captured -> %s", path);
    mqtt_core_publish("robot/laser/captured", path);
    s_robot_last_ms = now;
}

static void laser_handle_timeout(void *arg)
{
    (void)arg;
    laser_lock();
    s_laser_present = false;
    s_last_heartbeat_ms = 0;
    s_hold_streak_ms = 0;
    if (!s_laser_cfg.cumulative) {
        s_hold_total_ms = 0;
        s_relay_triggered = false;
        s_hold_completed = false;
    }
    laser_stop_audio();
    laser_unlock();
}

static void laser_arm_timeout(void)
{
    if (!s_laser_timeout) {
        esp_timer_create_args_t args = {
            .callback = laser_handle_timeout,
            .arg = NULL,
            .dispatch_method = ESP_TIMER_TASK,
            .name = "laser_timeout",
        };
        esp_timer_create(&args, &s_laser_timeout);
    }
    if (s_laser_timeout && esp_timer_is_active(s_laser_timeout)) {
        esp_timer_stop(s_laser_timeout);
    }
    if (s_laser_timeout) {
        esp_timer_start_once(s_laser_timeout, LASER_TIMEOUT_US);
    }
}

static void laser_maybe_trigger_relay(void)
{
    if (s_relay_triggered) return;
    int64_t base_ms = s_laser_cfg.cumulative ? s_hold_total_ms : s_hold_streak_ms;
    if (s_laser_cfg.hold_seconds > 0 && base_ms >= ((int64_t)s_laser_cfg.hold_seconds) * 1000) {
        laser_trigger_relay();
    }
}

static void laser_handle_heartbeat(const char *payload)
{
    (void)payload;
    laser_lock();
    if (!s_laser_cfg.enabled) {
        laser_unlock();
        return;
    }
    if (s_hold_completed) {
        // already triggered, keep timers paused but allow robot chatter
        laser_arm_timeout();
        laser_unlock();
        return;
    }
    int64_t now = now_ms();
    if (s_laser_present && s_last_heartbeat_ms > 0) {
        int64_t delta = now - s_last_heartbeat_ms;
        if (delta < 0) delta = 0;
        if (delta > 2000) delta = 2000;
        s_hold_total_ms += delta;
        s_hold_streak_ms += delta;
    } else {
        s_hold_streak_ms = 0;
    }
    s_laser_present = true;
    s_last_heartbeat_ms = now;
    laser_start_audio();
    laser_maybe_trigger_relay();
    laser_maybe_send_robot(now);
    laser_arm_timeout();
    laser_unlock();
}

static void laser_set_enabled_locked(bool en)
{
    if (s_laser_cfg.enabled == en) return;
    s_laser_cfg.enabled = en;
    if (!en) {
        s_laser_present = false;
        s_relay_triggered = false;
        s_hold_completed = false;
        s_hold_total_ms = 0;
        s_hold_streak_ms = 0;
        s_last_heartbeat_ms = 0;
        laser_stop_audio();
        if (s_laser_timeout && esp_timer_is_active(s_laser_timeout)) {
            esp_timer_stop(s_laser_timeout);
        }
    }
}

static bool pic_uid_allowed(int idx, const char *uid)
{
    if (idx < 0 || idx >= PIC_DEVICES || !uid || uid[0] == '\0') return false;
    const pic_device_cfg_t *d = &s_pic_cfg.dev[idx];
    for (int i = 0; i < d->count; ++i) {
        if (strcmp(d->uids[i], uid) == 0) return true;
    }
    return false;
}

static bool pic_all_match_locked(void)
{
    bool ok = true;
    bool any_active = false;

    for (int i = 0; i < PIC_DEVICES; ++i) {
        const pic_device_cfg_t *d = &s_pic_cfg.dev[i];

        if (d->count == 0) {
            // девайс не настроен – просто пропускаем
            ESP_LOGI(TAG, "check: dev=%d inactive (count=0), skip", i + 1);
            continue;
        }

        any_active = true;

        ESP_LOGI(TAG, "check: dev=%d count=%u last_uid='%s'",
                 i + 1, d->count, d->last_uid[0] ? d->last_uid : "<none>");

        if (!d->last_uid[0]) {
            ESP_LOGI(TAG, "check: dev=%d -> no last_uid, FAIL", i + 1);
            ok = false;
            continue;
        }

        bool allowed = pic_uid_allowed(i, d->last_uid);
        ESP_LOGI(TAG, "check: dev=%d -> allowed=%d", i + 1, allowed);
        if (!allowed) {
            ok = false;
        }
    }

    if (!any_active) {
        ESP_LOGW(TAG, "check: no active devices configured");
        return false; // или true, если хочешь "ничего не настроено = нейтрально"
    }

    return ok;
}

static bool pic_all_match(void)
{
    bool ok = false;
    pic_lock();
    ok = pic_all_match_locked();
    pic_unlock();
    return ok;
}



static void pic_handle_result(bool ok)
{
    int64_t now = now_ms();
    if (s_last_result_valid) {
        int64_t dt = now - s_last_result_ms;
        if (dt >= 0 && dt < 800 && ok == s_last_result_ok) {
            // Один и тот же результат (OK/FAIL) прилетел повторно слишком быстро – игнорируем
            ESP_LOGI(TAG, "result: duplicate %s within %lld ms, skip",
                     ok ? "OK" : "FAIL", (long long)dt);
            return;
        }
    }

    s_last_result_valid = true;
    s_last_result_ms = now;
    s_last_result_ok = ok;

    const char *light_topic = ok ? "pictures/lightsgreen" : "pictures/lightsred";
    const char *payload     = ok ? "ok" : "fail";
    ESP_LOGI(TAG, "result: %s -> publish %s='%s'",
             ok ? "OK" : "FAIL", light_topic, payload);

    mqtt_core_publish(light_topic, payload);

    char robot_path[96] = {0};
    char local_track[96] = {0};
    pic_lock();
    const char *robot_src = ok ? s_pic_cfg.track_ok : s_pic_cfg.track_fail;
    const char *local_src = ok ? s_pic_cfg.track_ok : s_pic_cfg.track_fail;
    strncpy(robot_path, robot_src, sizeof(robot_path) - 1);
    strncpy(local_track, local_src, sizeof(local_track) - 1);
    pic_unlock();

    if (robot_path[0]) {
        ESP_LOGI(TAG, "result: robot/speak='%s'", robot_path);
        mqtt_core_publish("robot/speak", robot_path);
    }

    if (local_track[0]) {
        ESP_LOGI(TAG, "result: local audio='%s'", local_track);
        audio_player_play(local_track);
    }
}

static esp_err_t send_ok(httpd_req_t *req, const char *mime, const char *body)
{
    httpd_resp_set_type(req, mime);
    return httpd_resp_send(req, body, HTTPD_RESP_USE_STRLEN);
}

static esp_err_t ping_handler(httpd_req_t *req)
{
    return send_ok(req, "text/plain", "pong");
}

static esp_err_t wifi_scan_handler(httpd_req_t *req)
{
    if (!s_scan_mutex) {
        s_scan_mutex = xSemaphoreCreateMutex();
    }
    if (!xSemaphoreTake(s_scan_mutex, pdMS_TO_TICKS(5000))) {
        return httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "scan busy");
    }
    wifi_scan_config_t scan_conf = {
        .ssid = NULL,
        .bssid = NULL,
        .channel = 0,
        .show_hidden = true,
    };
    esp_err_t err = esp_wifi_scan_start(&scan_conf, true);
    if (err != ESP_OK) {
        xSemaphoreGive(s_scan_mutex);
        return httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "scan failed");
    }

    uint16_t ap_num = 0;
    esp_wifi_scan_get_ap_num(&ap_num);
    wifi_ap_record_t *aps = calloc(ap_num, sizeof(wifi_ap_record_t));
    if (!aps) {
        xSemaphoreGive(s_scan_mutex);
        return httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "no mem");
    }
    esp_wifi_scan_get_ap_records(&ap_num, aps);

    char *buf = malloc(512);
    if (!buf) {
        free(aps);
        xSemaphoreGive(s_scan_mutex);
        return httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "no mem");
    }
    size_t len = 0;
    buf[len++] = '[';
    for (int i = 0; i < ap_num; ++i) {
        char entry[80];
        int w = snprintf(entry, sizeof(entry), "\"%s\"%s", aps[i].ssid, (i == ap_num - 1) ? "" : ",");
        if (w < 0 || len + w + 2 >= 512) break;
        memcpy(buf + len, entry, w);
        len += w;
    }
    buf[len++] = ']';
    buf[len] = 0;

    httpd_resp_set_type(req, "application/json");
    httpd_resp_send(req, buf, len);

    free(buf);
    free(aps);
    xSemaphoreGive(s_scan_mutex);
    return ESP_OK;
}

static void pic_handle_scan(int idx, const char *uid)
{
    if (idx < 0 || idx >= PIC_DEVICES || !uid) {
        ESP_LOGW(TAG, "scan: bad idx=%d or uid=NULL", idx);
        return;
    }

    ESP_LOGI(TAG, "scan: dev=%d, uid='%s'", idx + 1, uid);

    pic_lock();
    strncpy(s_pic_cfg.dev[idx].last_uid, uid, sizeof(s_pic_cfg.dev[idx].last_uid) - 1);
    s_pic_cfg.dev[idx].last_uid[sizeof(s_pic_cfg.dev[idx].last_uid) - 1] = 0;
    bool ok = pic_all_match_locked();
    pic_unlock();
    ESP_LOGI(TAG, "scan: after update -> all_match=%d", ok);

    // 🔊 ВОТ ЭТА СТРОКА — главное изменение:
    pic_handle_result(ok);
}



static void pic_handle_check(void)
{
    bool ok = pic_all_match();
    ESP_LOGI(TAG, "pic_handle_check(): ok=%d", ok);
    // НИКАКОГО звука здесь, только лог.
}

static void on_event_bus(const event_bus_message_t *msg)
{
    if (!msg || msg->type != EVENT_WEB_COMMAND) return;
    const char *t = msg->topic;
    if (strncmp(t, "pictures/scan/", 14) == 0) {
        int idx = atoi(t + 14) - 1;
        pic_handle_scan(idx, msg->payload);
    } else if (strncmp(t, "pictures/check", 14) == 0) {
        pic_handle_check();
    } else if (strncmp(t, "laser/laserOn", 13) == 0) {
        laser_handle_heartbeat(msg->payload);
    }
}

static esp_err_t status_handler(httpd_req_t *req)
{
    const app_config_t *cfg = config_store_get();
    char ip_buf[32] = "";
    esp_netif_ip_info_t ip;
    if (esp_netif_get_ip_info(esp_netif_get_handle_from_ifkey("WIFI_STA_DEF"), &ip) == ESP_OK && ip.ip.addr != 0) {
        snprintf(ip_buf, sizeof(ip_buf), IPSTR, IP2STR(&ip.ip));
    }
    char buf[960];
    mqtt_client_stats_t stats;
    mqtt_core_get_client_stats(&stats);
    audio_player_status_t a_status;
    audio_player_get_status(&a_status);
    uint64_t kb_total = 0, kb_free = 0;
    bool sd_ok = (esp_vfs_fat_info("/sdcard", &kb_total, &kb_free) == ESP_OK);
    uint64_t sd_total = sd_ok ? kb_total : 0;
    uint64_t sd_free = sd_ok ? kb_free : 0;
    snprintf(buf, sizeof(buf),
             "{\"wifi\":{\"ssid\":\"%s\",\"host\":\"%s\",\"sta_ip\":\"%s\",\"ap\":%s},"
             "\"mqtt\":{\"id\":\"%s\",\"port\":%d,\"keepalive\":%d},"
             "\"audio\":{\"volume\":%d,\"playing\":%s,\"paused\":%s,\"progress\":%d,\"pos_ms\":%d,\"dur_ms\":%d,\"bitrate\":%d,\"path\":\"%s\",\"message\":\"%s\",\"fmt\":%d},"
             "\"sd\":{\"ok\":%s,\"total\":%llu,\"free\":%llu},"
             "\"clients\":{\"total\":%u,\"pictures\":%u,\"laser\":%u,\"robot\":%u}}",
             cfg->wifi.ssid, cfg->wifi.hostname, ip_buf, network_is_ap_mode() ? "true" : "false",
             cfg->mqtt.broker_id, cfg->mqtt.port, cfg->mqtt.keepalive_seconds,
             audio_player_get_volume(),
             a_status.playing ? "true" : "false",
             a_status.paused ? "true" : "false",
             a_status.progress,
             a_status.pos_ms,
             a_status.dur_ms,
             a_status.bitrate_kbps,
             a_status.path,
             a_status.message,
             a_status.fmt,
             sd_ok ? "true" : "false",
             (unsigned long long)sd_total,
             (unsigned long long)sd_free,
             stats.total, stats.pictures, stats.laser, stats.robot);
    return send_ok(req, "application/json", buf);
}

static esp_err_t wifi_config_handler(httpd_req_t *req)
{
    char q[160];
    char ssid[32] = {0}, pass[64] = {0}, host[32] = {0};
    if (httpd_req_get_url_query_str(req, q, sizeof(q)) == ESP_OK) {
        httpd_query_key_value(q, "ssid", ssid, sizeof(ssid));
        httpd_query_key_value(q, "password", pass, sizeof(pass));
        httpd_query_key_value(q, "host", host, sizeof(host));
    }
    app_config_t cfg = *config_store_get();
    if (ssid[0]) strncpy(cfg.wifi.ssid, ssid, sizeof(cfg.wifi.ssid) - 1);
    if (pass[0]) strncpy(cfg.wifi.password, pass, sizeof(cfg.wifi.password) - 1);
    if (host[0]) strncpy(cfg.wifi.hostname, host, sizeof(cfg.wifi.hostname) - 1);
    ESP_ERROR_CHECK(config_store_set(&cfg));
    return send_ok(req, "text/plain", "wifi saved");
}

static esp_err_t mqtt_config_handler(httpd_req_t *req)
{
    char q[160];
    char id[16] = {0}, port[8] = {0}, keep[8] = {0};
    if (httpd_req_get_url_query_str(req, q, sizeof(q)) == ESP_OK) {
        httpd_query_key_value(q, "id", id, sizeof(id));
        httpd_query_key_value(q, "port", port, sizeof(port));
        httpd_query_key_value(q, "keepalive", keep, sizeof(keep));
    }
    app_config_t cfg = *config_store_get();
    if (id[0]) strncpy(cfg.mqtt.broker_id, id, sizeof(cfg.mqtt.broker_id) - 1);
    if (port[0]) cfg.mqtt.port = atoi(port);
    if (keep[0]) cfg.mqtt.keepalive_seconds = atoi(keep);
    ESP_ERROR_CHECK(config_store_set(&cfg));
    return send_ok(req, "text/plain", "mqtt saved");
}

static bool path_allowed(const char *path)
{
    if (!path) return false;
    const char *root = "/sdcard";
    size_t root_len = strlen(root);
    return strncmp(path, root, root_len) == 0;
}

static esp_err_t files_handler(httpd_req_t *req)
{
    char q[320];
    char path_enc[256] = {0};
    char dir_path[256] = "/sdcard";
    if (httpd_req_get_url_query_str(req, q, sizeof(q)) == ESP_OK) {
        httpd_query_key_value(q, "path", path_enc, sizeof(path_enc));
    }
    if (path_enc[0]) {
        url_decode(dir_path, sizeof(dir_path), path_enc);
        if (!path_allowed(dir_path)) {
            return httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "bad path");
        }
    }

    esp_err_t sd_err = audio_player_mount_sd();
    if (sd_err != ESP_OK) {
        char msg[64];
        snprintf(msg, sizeof(msg), "sd not mounted: %s", esp_err_to_name(sd_err));
        return httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, msg);
    }
    DIR *d = opendir(dir_path);
    if (!d) {
        return httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "sd not mounted");
    }
    httpd_resp_set_hdr(req, "Connection", "close");
    size_t resp_cap = 4096;
    char *resp = calloc(resp_cap, 1);
    if (!resp) {
        closedir(d);
        return httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "no mem");
    }
    size_t len = 0;
    resp[len++] = '[';
    struct dirent *ent;
    bool first = true;
    while ((ent = readdir(d)) != NULL) {
        const char *n = ent->d_name;
        // skip . and ..
        if (strcmp(n, ".") == 0 || strcmp(n, "..") == 0) {
            continue;
        }
        if (strcasecmp(n, "System Volume Information") == 0 || strcasecmp(n, "SYSTEM~1") == 0) {
            continue;
        }
        char full[200];
        int written = snprintf(full, sizeof(full), "%s/%s", dir_path, n);
        if (written <= 0 || written >= (int)sizeof(full)) {
            continue;
        }
        struct stat st;
        bool stat_ok = (stat(full, &st) == 0);
        bool is_dir = stat_ok ? S_ISDIR(st.st_mode) : false;
        bool ext_audio = false;
        {
            size_t nlen = strlen(n);
            if (nlen >= 4) {
                const char *ext = n + nlen - 4;
                ext_audio = (strcasecmp(ext, ".wav") == 0 || strcasecmp(ext, ".mp3") == 0 || strcasecmp(ext, ".ogg") == 0);
            }
        }
        if (!stat_ok && !ext_audio) {
            // Could not stat, but not an audio file by ext — treat as dir fallback so it is visible.
            is_dir = true;
        }
        if (!is_dir) {
            size_t nlen = strlen(n);
            if (nlen < 4) continue;
            const char *ext = n + nlen - 4;
            if (strcasecmp(ext, ".wav") != 0 && strcasecmp(ext, ".mp3") != 0 && strcasecmp(ext, ".ogg") != 0) {
                continue;
            }
        }
        long size_bytes = (is_dir || !stat_ok) ? 0 : st.st_size;
        int dur = 0;
        if (!is_dir) {
            size_t nlen = strlen(n);
            const char *ext = n + nlen - 4;
            if (strcasecmp(ext, ".wav") == 0) {
                FILE *wf = fopen(full, "rb");
                if (wf) {
                    struct __attribute__((packed)) wav_header {
                        char riff[4];
                        uint32_t size;
                        char wave[4];
                        char fmt[4];
                        uint32_t fmt_size;
                        uint16_t audio_format;
                        uint16_t num_channels;
                        uint32_t sample_rate;
                        uint32_t byte_rate;
                        uint16_t block_align;
                        uint16_t bits_per_sample;
                        char data_id[4];
                        uint32_t data_size;
                    } hdr;
                    if (fread(&hdr, 1, sizeof(hdr), wf) == sizeof(hdr) &&
                        strncmp(hdr.riff, "RIFF", 4) == 0 && strncmp(hdr.wave, "WAVE", 4) == 0 &&
                        hdr.audio_format == 1 && hdr.byte_rate > 0) {
                        dur = hdr.data_size / (int)hdr.byte_rate;
                    }
                    fclose(wf);
                }
            }
        }
        char entry[300];
        int w = snprintf(entry, sizeof(entry), "%s{\"path\":\"%s\",\"size\":%ld,\"dur\":%d,\"dir\":%s}",
                         first ? "" : ",", full, size_bytes, dur, is_dir ? "true" : "false");
        if (w < 0) {
            continue;
        }
        if (len + (size_t)w + 2 >= resp_cap) {
            size_t new_cap = resp_cap * 2;
            while (new_cap <= len + (size_t)w + 2) new_cap *= 2;
            char *nresp = realloc(resp, new_cap);
            if (!nresp) {
                free(resp);
                closedir(d);
                return httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "no mem");
            }
            resp = nresp;
            resp_cap = new_cap;
        }
        memcpy(resp + len, entry, (size_t)w);
        len += (size_t)w;
        first = false;
    }
    closedir(d);
    if (len + 2 >= resp_cap) {
        char *nresp = realloc(resp, resp_cap + 2);
        if (nresp) {
            resp = nresp;
            resp_cap += 2;
        }
    }
    resp[len++] = ']';
    resp[len] = 0;
    esp_err_t r = send_ok(req, "application/json", resp);
    free(resp);
    return r;
}

static esp_err_t audio_play_handler(httpd_req_t *req)
{
    char query[520];
    char path_enc[512] = {0};
    char path[512] = {0};
    char vol[8] = {0};
    if (httpd_req_get_url_query_str(req, query, sizeof(query)) == ESP_OK) {
        httpd_query_key_value(query, "path", path_enc, sizeof(path_enc));
        httpd_query_key_value(query, "volume", vol, sizeof(vol));
    }
    url_decode(path, sizeof(path), path_enc);
    esp_err_t sd_err = audio_player_mount_sd();
    if (sd_err != ESP_OK) {
        char msg[64];
        snprintf(msg, sizeof(msg), "sd not mounted: %s", esp_err_to_name(sd_err));
        return httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, msg);
    }
    if (path[0] == '\0') {
        return httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "path required");
    }
    if (vol[0]) {
        audio_player_set_volume(atoi(vol));
    }
    event_bus_message_t msg = {.type = EVENT_AUDIO_PLAY};
    strncpy(msg.payload, path, sizeof(msg.payload) - 1);
    event_bus_post(&msg, pdMS_TO_TICKS(50));
    return send_ok(req, "text/plain", "play");
}

static esp_err_t audio_stop_handler(httpd_req_t *req)
{
    audio_player_stop();
    return send_ok(req, "text/plain", "stop");
}

static esp_err_t audio_pause_handler(httpd_req_t *req)
{
    audio_player_pause();
    return send_ok(req, "text/plain", "pause");
}

static esp_err_t audio_resume_handler(httpd_req_t *req)
{
    audio_player_resume();
    return send_ok(req, "text/plain", "resume");
}

static esp_err_t audio_volume_handler(httpd_req_t *req)
{
    char q[32];
    char val[8] = {0};
    if (httpd_req_get_url_query_str(req, q, sizeof(q)) == ESP_OK) {
        httpd_query_key_value(q, "val", val, sizeof(val));
    }
    int v = atoi(val);
    audio_player_set_volume(v);
    return send_ok(req, "text/plain", "vol set");
}

static esp_err_t audio_seek_handler(httpd_req_t *req)
{
    char q[64];
    char pos[16] = {0};
    if (httpd_req_get_url_query_str(req, q, sizeof(q)) != ESP_OK) {
        return httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "pos required");
    }
    httpd_query_key_value(q, "pos", pos, sizeof(pos));
    int ms = atoi(pos);
    if (ms < 0) ms = 0;
    esp_err_t err = audio_player_seek((uint32_t)ms);
    if (err != ESP_OK) {
        return httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "seek failed");
    }
    return send_ok(req, "text/plain", "seek");
}

static esp_err_t pictures_config_handler(httpd_req_t *req)
{
    char *resp = calloc(4096, 1);
    if (!resp) {
        return httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "no mem");
    }
    pic_cfg_t snapshot = {0};
    pic_lock();
    snapshot = s_pic_cfg;
    pic_unlock();
    size_t len = 0;
    #define APPEND(fmt, ...) do { int w = snprintf(resp + len, 4096 - len, fmt, ##__VA_ARGS__); if (w < 0 || (size_t)w >= 4096 - len) { free(resp); return httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "resp too long"); } len += (size_t)w; } while (0)
    APPEND("{\"ok\":\"%s\",\"fail\":\"%s\",\"devices\":[", snapshot.track_ok, snapshot.track_fail);
    for (int i = 0; i < PIC_DEVICES; ++i) {
        APPEND("%s{\"idx\":%d,\"last\":\"%s\",\"uids\":[", (i == 0 ? "" : ","), i + 1, snapshot.dev[i].last_uid);
        for (int j = 0; j < snapshot.dev[i].count; ++j) {
            APPEND("%s\"%s\"", (j == 0 ? "" : ","), snapshot.dev[i].uids[j]);
        }
        APPEND("]}");
    }
    APPEND("]}");
    #undef APPEND
    httpd_resp_set_type(req, "application/json");
    esp_err_t r = httpd_resp_send(req, resp, len);
    free(resp);
    return r;
}

static esp_err_t pictures_device_save_handler(httpd_req_t *req)
{
    char q[512];
    if (httpd_req_get_url_query_str(req, q, sizeof(q)) != ESP_OK) {
        return httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "query required");
    }

    char idxs[8] = {0};
    char uids_enc[256] = {0};
    char uids_dec[256] = {0};

    httpd_query_key_value(q, "idx", idxs, sizeof(idxs));
    httpd_query_key_value(q, "uids", uids_enc, sizeof(uids_enc));

    int idx = atoi(idxs) - 1;
    if (idx < 0 || idx >= PIC_DEVICES) {
        return httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "bad idx");
    }

    // 🔧 вот эта строка чинит проблему
    url_decode(uids_dec, sizeof(uids_dec), uids_enc);

    pic_lock();
    // и уже декодированную строку режем по запятым
    parse_uids_csv(uids_dec, s_pic_cfg.dev[idx].uids, &s_pic_cfg.dev[idx].count);

    esp_err_t err = pic_save(&s_pic_cfg);
    pic_unlock();
    if (err != ESP_OK) {
        return httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "nvs save failed");
    }
    httpd_resp_set_hdr(req, "Connection", "close");
    return send_ok(req, "text/plain", "saved");
}


static esp_err_t pictures_tracks_save_handler(httpd_req_t *req)
{
    char q[384];
    char ok[96] = {0}, fail[96] = {0};
    if (httpd_req_get_url_query_str(req, q, sizeof(q)) == ESP_OK) {
        httpd_query_key_value(q, "ok", ok, sizeof(ok));
        httpd_query_key_value(q, "fail", fail, sizeof(fail));
    }
    char ok_dec[96] = {0}, fail_dec[96] = {0};
    url_decode(ok_dec, sizeof(ok_dec), ok);
    url_decode(fail_dec, sizeof(fail_dec), fail);
    char ok_copy[96] = {0};
    char fail_copy[96] = {0};
    pic_lock();
    if (ok_dec[0]) strncpy(s_pic_cfg.track_ok, ok_dec, sizeof(s_pic_cfg.track_ok) - 1);
    if (fail_dec[0]) strncpy(s_pic_cfg.track_fail, fail_dec, sizeof(s_pic_cfg.track_fail) - 1);
    esp_err_t err = pic_save(&s_pic_cfg);
    strncpy(ok_copy, s_pic_cfg.track_ok, sizeof(ok_copy) - 1);
    strncpy(fail_copy, s_pic_cfg.track_fail, sizeof(fail_copy) - 1);
    pic_unlock();
    ESP_LOGI(TAG, "pictures tracks saved ok='%s' fail='%s' err=%s", ok_copy, fail_copy, esp_err_to_name(err));
    if (err != ESP_OK) {
        return httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "nvs save failed");
    }
    httpd_resp_set_hdr(req, "Connection", "close");
    return send_ok(req, "text/plain", "tracks saved");
}

static esp_err_t pictures_addmode_handler(httpd_req_t *req)
{
    char q[64];
    char mode[8] = {0};
    if (httpd_req_get_url_query_str(req, q, sizeof(q)) == ESP_OK) {
        httpd_query_key_value(q, "mode", mode, sizeof(mode));
    }
    const char *m = (strcmp(mode, "on") == 0) ? "on" : "off";
    mqtt_core_publish("pictures/add_mode", m);
    return send_ok(req, "text/plain", "add mode sent");
}

static esp_err_t pictures_scan_handler(httpd_req_t *req)
{
    // Шлём команду сканирования всем pic-клиентам
    mqtt_core_publish("pictures/cmd/scan", "scan");

    // Можно сразу что-то вернуть фронтенду – просто "ок, команда ушла"
    const char *resp = "{\"ok\":true}";
    return send_ok(req, "application/json", resp);
}

static esp_err_t pictures_check_handler(httpd_req_t *req)
{
    bool ok = pic_all_match();
    ESP_LOGI(TAG, "/api/pictures/check -> ok=%d", ok);

    char resp[32];
    snprintf(resp, sizeof(resp), "{\"ok\":%s}", ok ? "true" : "false");
    return send_ok(req, "application/json", resp);
}

static esp_err_t laser_config_handler(httpd_req_t *req)
{
    char resp[320];
    laser_cfg_t cfg = {0};
    laser_lock();
    cfg = s_laser_cfg;
    laser_unlock();
    int w = snprintf(resp, sizeof(resp),
                     "{\"hold\":\"%s\",\"relay\":\"%s\",\"seconds\":%d,\"mode\":\"%s\",\"enabled\":%s}",
                     cfg.track_hold, cfg.track_relay, cfg.hold_seconds,
                     cfg.cumulative ? "cumulative" : "continuous",
                     cfg.enabled ? "true" : "false");
    if (w < 0 || w >= (int)sizeof(resp)) {
        return httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "resp too long");
    }
    return send_ok(req, "application/json", resp);
}

static esp_err_t robot_config_handler(httpd_req_t *req)
{
    char resp[320];
    int w = snprintf(resp, sizeof(resp),
                     "{\"laser\":\"%s\",\"sarcastic\":\"%s\",\"broken\":\"%s\"}",
                     s_robot_cfg.laser_dir, s_robot_cfg.sarcastic_dir, s_robot_cfg.broken_dir);
    if (w < 0 || w >= (int)sizeof(resp)) {
        return httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "resp too long");
    }
    return send_ok(req, "application/json", resp);
}

static esp_err_t laser_save_handler(httpd_req_t *req)
{
    char q[384];
    char hold_enc[96] = {0}, relay_enc[96] = {0}, mode[16] = {0}, sec[8] = {0}, en[8] = {0};
    if (httpd_req_get_url_query_str(req, q, sizeof(q)) == ESP_OK) {
        httpd_query_key_value(q, "hold", hold_enc, sizeof(hold_enc));
        httpd_query_key_value(q, "relay", relay_enc, sizeof(relay_enc));
        httpd_query_key_value(q, "mode", mode, sizeof(mode));
        httpd_query_key_value(q, "seconds", sec, sizeof(sec));
        httpd_query_key_value(q, "enabled", en, sizeof(en));
    }
    char hold[96] = {0}, relay[96] = {0};
    url_decode(hold, sizeof(hold), hold_enc);
    url_decode(relay, sizeof(relay), relay_enc);
    bool en_param = false;
    bool en_val = false;
    if (en[0]) {
        en_param = true;
        en_val = (strcasecmp(en, "true") == 0) || (strcmp(en, "1") == 0) || (strcasecmp(en, "on") == 0);
    }
    laser_lock();
    if (hold[0]) strncpy(s_laser_cfg.track_hold, hold, sizeof(s_laser_cfg.track_hold) - 1);
    if (relay[0]) strncpy(s_laser_cfg.track_relay, relay, sizeof(s_laser_cfg.track_relay) - 1);
    if (sec[0]) {
        int v = atoi(sec);
        if (v > 0 && v < 3600) {
            s_laser_cfg.hold_seconds = v;
        }
    }
    if (mode[0]) {
        s_laser_cfg.cumulative = (strcasecmp(mode, "cumulative") == 0);
    }
    if (en_param) {
        laser_set_enabled_locked(en_val);
    }
    s_relay_triggered = false;
    s_hold_total_ms = 0;
    s_hold_streak_ms = 0;
    esp_err_t err = laser_save(&s_laser_cfg);
    laser_cfg_t snapshot = s_laser_cfg;
    laser_unlock();
    ESP_LOGI(TAG, "laser saved hold='%s' relay='%s' sec=%d mode=%s en=%s err=%s",
             snapshot.track_hold, snapshot.track_relay, snapshot.hold_seconds,
             snapshot.cumulative ? "cumulative" : "continuous",
             snapshot.enabled ? "on" : "off", esp_err_to_name(err));
    if (err != ESP_OK) {
        return httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "nvs save failed");
    }
    return send_ok(req, "text/plain", "laser saved");
}

static esp_err_t robot_save_handler(httpd_req_t *req)
{
    char q[320];
    char laser_enc[96] = {0}, sarcasm_enc[96] = {0}, broken_enc[96] = {0};
    if (httpd_req_get_url_query_str(req, q, sizeof(q)) == ESP_OK) {
        httpd_query_key_value(q, "laser", laser_enc, sizeof(laser_enc));
        httpd_query_key_value(q, "sarcastic", sarcasm_enc, sizeof(sarcasm_enc));
        httpd_query_key_value(q, "broken", broken_enc, sizeof(broken_enc));
    }
    char laser[96] = {0}, sarcasm[96] = {0}, broken[96] = {0};
    url_decode(laser, sizeof(laser), laser_enc);
    url_decode(sarcasm, sizeof(sarcasm), sarcasm_enc);
    url_decode(broken, sizeof(broken), broken_enc);
    if (laser[0]) strncpy(s_robot_cfg.laser_dir, laser, sizeof(s_robot_cfg.laser_dir) - 1);
    if (sarcasm[0]) strncpy(s_robot_cfg.sarcastic_dir, sarcasm, sizeof(s_robot_cfg.sarcastic_dir) - 1);
    if (broken[0]) strncpy(s_robot_cfg.broken_dir, broken, sizeof(s_robot_cfg.broken_dir) - 1);
    esp_err_t err = robot_save(&s_robot_cfg);
    if (err != ESP_OK) {
        return httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "nvs save failed");
    }
    return send_ok(req, "text/plain", "robot cfg saved");
}

static esp_err_t robot_presets_get_handler(httpd_req_t *req)
{
    char resp[ROBOT_PRESET_COUNT * (ROBOT_NAME_LEN + 4) + 16];
    size_t len = 0;
    len += snprintf(resp + len, sizeof(resp) - len, "[");
    for (int i = 0; i < ROBOT_PRESET_COUNT; ++i) {
        len += snprintf(resp + len, sizeof(resp) - len, "%s\"%s\"", i == 0 ? "" : ",", s_robot_presets.names[i]);
    }
    len += snprintf(resp + len, sizeof(resp) - len, "]");
    httpd_resp_set_type(req, "application/json");
    return httpd_resp_send(req, resp, len);
}

static void sanitize_name(const char *src, char *dst, size_t dst_sz)
{
    if (!dst || dst_sz == 0) return;
    size_t w = 0;
    if (src) {
        for (size_t i = 0; src[i] && w + 1 < dst_sz; ++i) {
            char c = src[i];
            if (isalnum((int)c) || c == '_' || c == '-') {
                dst[w++] = c;
            }
        }
    }
    dst[w] = 0;
}

static esp_err_t robot_presets_set_handler(httpd_req_t *req)
{
    char q[128];
    if (httpd_req_get_url_query_str(req, q, sizeof(q)) != ESP_OK) {
        return httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "query required");
    }
    char idxs[8] = {0};
    char name_raw[ROBOT_NAME_LEN] = {0};
    httpd_query_key_value(q, "idx", idxs, sizeof(idxs));
    httpd_query_key_value(q, "name", name_raw, sizeof(name_raw));
    int idx = atoi(idxs);
    if (idx < 0 || idx >= ROBOT_PRESET_COUNT) {
        return httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "bad idx");
    }
    char clean[ROBOT_NAME_LEN] = {0};
    sanitize_name(name_raw, clean, sizeof(clean));
    strncpy(s_robot_presets.names[idx], clean, sizeof(s_robot_presets.names[idx]) - 1);
    robot_presets_save(&s_robot_presets);
    return send_ok(req, "text/plain", "saved");
}

static esp_err_t robot_presets_play_handler(httpd_req_t *req)
{
    char q[64];
    if (httpd_req_get_url_query_str(req, q, sizeof(q)) != ESP_OK) {
        return httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "query required");
    }
    char idxs[8] = {0};
    httpd_query_key_value(q, "idx", idxs, sizeof(idxs));
    int idx = atoi(idxs);
    if (idx < 0 || idx >= ROBOT_PRESET_COUNT) {
        return httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "bad idx");
    }
    const char *name = s_robot_presets.names[idx];
    if (!name || strlen(name) == 0) {
        return httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "empty slot");
    }
    char path[128];
    snprintf(path, sizeof(path), "/sdcard/audio/%s.mp3", name);
    mqtt_core_publish("audio/play", path);
    return send_ok(req, "text/plain", "play");
}

static esp_err_t laser_enable_handler(httpd_req_t *req)
{
    char q[64];
    char state[8] = {0};
    if (httpd_req_get_url_query_str(req, q, sizeof(q)) == ESP_OK) {
        httpd_query_key_value(q, "state", state, sizeof(state));
    }
    bool en = (strcasecmp(state, "on") == 0) || (strcmp(state, "1") == 0) || (strcasecmp(state, "true") == 0);
    laser_lock();
    laser_set_enabled_locked(en);
    laser_save(&s_laser_cfg);
    bool current = s_laser_cfg.enabled;
    laser_unlock();
    char resp[32];
    snprintf(resp, sizeof(resp), "{\"enabled\":%s}", current ? "true" : "false");
    return send_ok(req, "application/json", resp);
}

static esp_err_t publish_handler(httpd_req_t *req)
{
    char query[160];
    char topic_enc[96] = {0};
    char payload_enc[96] = {0};
    char topic[96] = {0};
    char payload[96] = {0};
    if (httpd_req_get_url_query_str(req, query, sizeof(query)) == ESP_OK) {
        httpd_query_key_value(query, "topic", topic_enc, sizeof(topic_enc));
        httpd_query_key_value(query, "payload", payload_enc, sizeof(payload_enc));
    }
    url_decode(topic, sizeof(topic), topic_enc);
    url_decode(payload, sizeof(payload), payload_enc);
    if (topic[0] == '\0') {
        return httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "topic required");
    }
    event_bus_message_t msg = {.type = EVENT_WEB_COMMAND};
    strncpy(msg.topic, topic, sizeof(msg.topic) - 1);
    strncpy(msg.payload, payload, sizeof(msg.payload) - 1);
    event_bus_post(&msg, pdMS_TO_TICKS(50));
    return send_ok(req, "text/plain", "sent");
}

static esp_err_t ap_stop_handler(httpd_req_t *req)
{
    network_stop_ap();
    return send_ok(req, "text/plain", "ap stopped");
}

static esp_err_t root_get_handler(httpd_req_t *req)
{
    static const char page[] =
        "<!DOCTYPE html><html><head><meta charset='utf-8'><title>Broker</title>"
        "<style>"
        "body{margin:0;padding:0;font-family:Arial,sans-serif;background:#0b0d12;color:#e6e7ea;display:flex;justify-content:center;}"
        ".page{width:100%;max-width:1400px;margin:0 auto;}"
        "header{padding:18px 24px;border-bottom:1px solid #181c26;background:#0f1219;position:sticky;top:0;display:flex;justify-content:center;z-index:40;}"
        ".tabs{display:flex;flex-wrap:wrap;--tab-gap:10px;gap:var(--tab-gap);padding:10px 12px;background:#0f1219;border:1px solid #181c26;border-radius:12px;margin:0 auto 12px;width:100%;max-width:1200px;justify-content:center;}"
        ".tab{height:42px;flex:0 0 calc((100% - 7*var(--tab-gap))/8);max-width:calc((100% - 7*var(--tab-gap))/8);min-width:100px;padding:0 12px;border-radius:12px;cursor:pointer;border:2px solid var(--tab-color,#121621);background:var(--tab-color,#121621);color:#0b0d13;font-weight:600;display:inline-flex;align-items:center;justify-content:center;gap:8px;font-size:13px;box-shadow:0 6px 18px rgba(0,0,0,0.3);transition:transform .15s ease,box-shadow .2s ease,opacity .2s ease;}"
        ".tab:not(.active){opacity:0.88;}"
        ".tab.active{transform:translateY(-1px);box-shadow:0 10px 26px rgba(0,0,0,0.45),0 0 0 2px rgba(255,255,255,0.2);}"
        ".tab .tab-icon{width:20px;height:20px;border-radius:8px;background:rgba(11,13,19,0.15);display:inline-flex;align-items:center;justify-content:center;background-repeat:no-repeat;background-position:center;background-size:16px;color:#0b0d13;flex-shrink:0;}"
        ".tab .tab-label{white-space:nowrap;}"
        ".tab[data-icon='status'] .tab-icon{background-image:url(\"data:image/svg+xml,%3Csvg%20xmlns%3D%27http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%27%20viewBox%3D%270%200%2024%2024%27%20stroke%3D%27%25230b0d13%27%20stroke-width%3D%272%27%20fill%3D%27none%27%20stroke-linecap%3D%27round%27%20stroke-linejoin%3D%27round%27%3E%3Cpolyline%20points%3D%273%2012%207%2012%2010%206%2014%2018%2017%2012%2021%2012%27%2F%3E%3C%2Fsvg%3E\");}"
        ".tab[data-icon='audio'] .tab-icon{background-image:url(\"data:image/svg+xml,%3Csvg%20xmlns%3D%27http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%27%20viewBox%3D%270%200%2024%2024%27%20stroke%3D%27%25230b0d13%27%20stroke-width%3D%272%27%20fill%3D%27none%27%20stroke-linecap%3D%27round%27%20stroke-linejoin%3D%27round%27%3E%3Cpolygon%20points%3D%275%209%209%209%2013%205%2013%2019%209%2015%205%2015%205%209%27%2F%3E%3Cpath%20d%3D%27M16%209c1.5%201.5%201.5%204.5%200%206%27%2F%3E%3Cpath%20d%3D%27M19%207c2.5%202.5%202.5%207.5%200%2010%27%2F%3E%3C%2Fsvg%3E\");}"
        ".tab[data-icon='pictures'] .tab-icon{background-image:url(\"data:image/svg+xml,%3Csvg%20xmlns%3D%27http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%27%20viewBox%3D%270%200%2024%2024%27%20stroke%3D%27%25230b0d13%27%20stroke-width%3D%272%27%20fill%3D%27none%27%20stroke-linecap%3D%27round%27%20stroke-linejoin%3D%27round%27%3E%3Crect%20x%3D%273%27%20y%3D%275%27%20width%3D%2718%27%20height%3D%2714%27%20rx%3D%272%27%2F%3E%3Ccircle%20cx%3D%278.5%27%20cy%3D%2710%27%20r%3D%271.5%27%2F%3E%3Cpath%20d%3D%27M21%2015l-5-5-4%204-2-2-5%205%27%2F%3E%3C%2Fsvg%3E\");}"
        ".tab[data-icon='laser'] .tab-icon{background-image:url(\"data:image/svg+xml,%3Csvg%20xmlns%3D%27http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%27%20viewBox%3D%270%200%2024%2024%27%20stroke%3D%27%25230b0d13%27%20stroke-width%3D%272%27%20fill%3D%27none%27%20stroke-linecap%3D%27round%27%20stroke-linejoin%3D%27round%27%3E%3Ccircle%20cx%3D%2712%27%20cy%3D%2712%27%20r%3D%277%27%2F%3E%3Ccircle%20cx%3D%2712%27%20cy%3D%2712%27%20r%3D%272%27%2F%3E%3Cline%20x1%3D%2712%27%20y1%3D%273%27%20x2%3D%2712%27%20y2%3D%271%27%2F%3E%3Cline%20x1%3D%2712%27%20y1%3D%2723%27%20x2%3D%2712%27%20y2%3D%2721%27%2F%3E%3Cline%20x1%3D%273%27%20y1%3D%2712%27%20x2%3D%271%27%20y2%3D%2712%27%2F%3E%3Cline%20x1%3D%2723%27%20y1%3D%2712%27%20x2%3D%2721%27%20y2%3D%2712%27%2F%3E%3C%2Fsvg%3E\");}"
        ".tab[data-icon='robot'] .tab-icon{background-image:url(\"data:image/svg+xml,%3Csvg%20xmlns%3D%27http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%27%20viewBox%3D%270%200%2024%2024%27%20stroke%3D%27%25230b0d13%27%20stroke-width%3D%272%27%20fill%3D%27none%27%20stroke-linecap%3D%27round%27%20stroke-linejoin%3D%27round%27%3E%3Crect%20x%3D%275%27%20y%3D%279%27%20width%3D%2714%27%20height%3D%2710%27%20rx%3D%272%27%2F%3E%3Ccircle%20cx%3D%279%27%20cy%3D%2713%27%20r%3D%271%27%2F%3E%3Ccircle%20cx%3D%2715%27%20cy%3D%2713%27%20r%3D%271%27%2F%3E%3Cpath%20d%3D%27M8%2017h8%27%2F%3E%3Cpath%20d%3D%27M12%205V3%27%2F%3E%3C%2Fsvg%3E\");}"
        ".tab[data-icon='settings'] .tab-icon{background-image:url(\"data:image/svg+xml,%3Csvg%20xmlns%3D%27http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%27%20viewBox%3D%270%200%2024%2024%27%20stroke%3D%27%25230b0d13%27%20stroke-width%3D%272%27%20fill%3D%27none%27%20stroke-linecap%3D%27round%27%20stroke-linejoin%3D%27round%27%3E%3Ccircle%20cx%3D%2712%27%20cy%3D%2712%27%20r%3D%273%27%2F%3E%3Cpath%20d%3D%27M19.4%2015a1.65%201.65%200%200%200%20.33%201.82l.06.06a2%202%200%200%201-2.83%202.83l-.06-.06a1.65%201.65%200%200%200-1.82-.33%201.65%201.65%200%200%200-1%201.51V21a2%202%200%200%201-4%200v-.09A1.65%201.65%200%200%200%209%2019.4a1.65%201.65%200%200%200-1.82.33l-.06.06a2%202%200%200%201-2.83-2.83l.06-.06a1.65%201.65%200%200%200%20.33-1.82%201.65%201.65%200%200%200-1.51-1H3a2%202%200%200%201%200-4h.09A1.65%201.65%200%200%200%204.6%209%201.65%201.65%200%200%200%204.27%207.18l-.06-.06A2%202%200%200%201%207.04%204.3l.06.06A1.65%201.65%200%200%200%208.91%204a1.65%201.65%200%200%200%201-1.51V3a2%202%200%200%201%204%200v.09A1.65%201.65%200%200%200%2015%204.6a1.65%201.65%200%200%200%201.82-.33l.06-.06a2%202%200%200%201%202.83%202.83l-.06.06A1.65%201.65%200%200%200%2019.74%209%201.65%201.65%200%200%200%2021.25%2010H21a2%202%200%200%201%200%204h-.09a1.65%201.65%200%200%200-1.51%201z%27%2F%3E%3C%2Fsvg%3E\");}"
        ".tab[data-icon='network'] .tab-icon{background-image:url(\"data:image/svg+xml,%3Csvg%20xmlns%3D%27http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%27%20viewBox%3D%270%200%2024%2024%27%20stroke%3D%27%25230b0d13%27%20stroke-width%3D%272%27%20fill%3D%27none%27%20stroke-linecap%3D%27round%27%20stroke-linejoin%3D%27round%27%3E%3Cpath%20d%3D%27M5%2012a9%209%200%200%201%2014%200%27%2F%3E%3Cpath%20d%3D%27M8.5%2015.5a5%205%200%200%201%207%200%27%2F%3E%3Cpath%20d%3D%27M12%2019h.01%27%2F%3E%3C%2Fsvg%3E\");}"
        ".tab[data-icon='power'] .tab-icon{background-image:url(\"data:image/svg+xml,%3Csvg%20xmlns%3D%27http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%27%20viewBox%3D%270%200%2024%2024%27%20stroke%3D%27%25230b0d13%27%20stroke-width%3D%272%27%20fill%3D%27none%27%20stroke-linecap%3D%27round%27%20stroke-linejoin%3D%27round%27%3E%3Cline%20x1%3D%2712%27%20y1%3D%272%27%20x2%3D%2712%27%20y2%3D%2712%27%2F%3E%3Cpath%20d%3D%27M5.5%207.5a7%207%200%201%200%2013%200%27%2F%3E%3C%2Fsvg%3E\");}"
        ".pane{padding:24px;display:none;max-width:1200px;margin:0 auto;} .pane.active{display:block;}"
        ".card{background:#121621;border:1px solid #1f2430;border-radius:12px;padding:16px;margin:0 auto 14px;box-shadow:0 10px 30px rgba(0,0,0,0.25);}"
        "h3,h4{margin:0 0 10px;color:#f0f2f5;font-weight:600;}"
        "input,select{background:#0c0e12;border:1px solid #2b3344;color:#e6e7ea;border-radius:8px;padding:10px 12px;margin:4px 8px 4px 0;min-width:220px;}"
        "button:not(.icon-btn){background:#3b82f6;border:none;color:#fff;border-radius:10px;padding:10px 16px;margin:4px 8px 4px 0;cursor:pointer;font-weight:600;box-shadow:0 6px 18px rgba(59,130,246,0.35);}button:not(.icon-btn):hover{background:#2563eb;}"
        ".muted{color:#8b92a3;font-size:13px;}"
        ".row{display:flex;flex-wrap:wrap;align-items:center;}"
        ".controls-row{display:flex;align-items:center;gap:16px;flex-wrap:wrap;}"
        ".volume-control{display:flex;align-items:center;gap:10px;min-width:200px;flex:1 1 200px;}"
        ".volume-control input{max-width:220px;}"
        ".control-buttons{display:flex;gap:10px;flex-shrink:0;}"
        ".mode-row{gap:10px;}"
        ".mode-btn{min-width:120px;font-weight:600;border:2px solid #1f2430;background:#0c0e12;color:#cbd5e1;border-radius:10px;padding:10px 14px;cursor:pointer;transition:box-shadow .2s ease,border-color .2s ease,color .2s ease,background .2s ease;}"
        ".mode-btn.active{border-color:#3b82f6;background:#0f172a;color:#fff;box-shadow:0 0 12px rgba(59,130,246,0.35);}"
        ".mode-btn.mode-last{box-shadow:0 0 0 2px rgba(59,130,246,0.6),0 0 16px rgba(59,130,246,0.35);}"
        ".progress-box{border:1px solid #1f2430;border-radius:10px;background:#0c0e12;padding:8px 12px;margin-top:10px;display:flex;flex-direction:column;gap:4px;}"
        ".progress-row{display:flex;flex-direction:column;align-items:stretch;gap:2px;}"
        ".progress-row input{flex:0 0 auto;min-width:220px;width:100%;}"
        ".progress-row .muted{font-size:12px;}"
        "input[type=range]{-webkit-appearance:none;appearance:none;padding:0;background:transparent;border:none;min-width:0;height:26px;display:block;margin:4px 0;}"
        "input[type=range]:focus{outline:none;}"
        "input[type=range]::-webkit-slider-runnable-track{width:100%;height:6px;background:#1f2430;border-radius:999px;border:1px solid #2b3344;}"
        "input[type=range]::-webkit-slider-thumb{-webkit-appearance:none;appearance:none;width:16px;height:16px;border-radius:50%;background:#3b82f6;border:2px solid #0b0d13;margin-top:-6px;box-shadow:0 0 0 2px rgba(59,130,246,0.3);cursor:pointer;}"
        "input[type=range]::-moz-range-track{width:100%;height:6px;background:#1f2430;border-radius:999px;border:1px solid #2b3344;}"
        "input[type=range]::-moz-range-thumb{width:16px;height:16px;border-radius:50%;background:#3b82f6;border:2px solid #0b0d13;cursor:pointer;}"
        "input[type=range]::-ms-track{width:100%;height:6px;background:transparent;border-color:transparent;color:transparent;}"
        "input[type=range]::-ms-fill-lower{background:#1f2430;border-radius:999px;border:1px solid #2b3344;}"
        "input[type=range]::-ms-fill-upper{background:#1f2430;border-radius:999px;border:1px solid #2b3344;}"
        "input[type=range]::-ms-thumb{width:16px;height:16px;border-radius:50%;background:#3b82f6;border:2px solid #0b0d13;cursor:pointer;margin-top:0;}"
        ".list{margin:6px 0;}"
        ".pill{display:inline-block;padding:6px 10px;border-radius:12px;background:#1f2430;margin:4px;color:#cbd5e1;font-size:13px;cursor:pointer;}"
        ".badge{display:inline-block;padding:6px 10px;border-radius:12px;background:#1f2430;margin-left:8px;font-size:12px;}"
        ".hero{padding:16px 24px;background:#0f1219;border:1px solid #181c26;border-radius:12px;margin:0 auto 12px;max-width:1200px;display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap;}"
        ".hero h2{margin:0;font-weight:700;color:#f0f2f5;}"
        ".hero .status-clusters{display:flex;gap:16px;align-items:center;flex-wrap:wrap;margin-left:auto;}"
        ".device-cluster{display:flex;align-items:center;gap:6px;background:#0c0e12;border:1px solid #1f2430;padding:6px 10px;border-radius:10px;min-width:110px;justify-content:center;}"
        ".device-cluster .label{font-size:12px;color:#8b92a3;display:flex;align-items:center;gap:4px;}"
        ".device-cluster .dots{display:flex;gap:4px;}"
        ".device-cluster .dots span{width:10px;height:10px;border-radius:50%;background:#1f2937;}"
        ".device-icon{font-size:16px;}"
        ".stat-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:10px;margin-top:12px;}"
        ".stat{background:#0c0e12;border:1px solid #1f2430;border-radius:10px;padding:10px 12px;}"
        ".stat .label{display:block;color:#8b92a3;font-size:12px;margin-bottom:4px;}"
        ".stat .value{font-weight:600;color:#e6e7ea;}"
        ".dots span{display:inline-block;width:10px;height:10px;border-radius:50%;margin-right:4px;background:#1f2937;}"
        ".small{font-size:12px;}"
        ".status-row{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin:6px 0;}"
        ".file-browser{margin-top:12px;border:1px solid #1f2430;background:#0f1219;border-radius:10px;padding:12px;max-width:1200px;margin-left:auto;margin-right:auto;}"
        ".folder-row{display:flex;flex-wrap:wrap;gap:10px;margin:10px auto;width:100%;max-width:calc(8*100px + 7*10px);justify-content:center;min-height:50px;align-items:center;}"
        ".folder-chip{width:100px;height:50px;border:3px solid #1f2430;border-radius:10px;background:#000;cursor:pointer;font-size:11px;color:#e5e7eb;display:flex;align-items:center;justify-content:center;box-sizing:border-box;overflow:hidden;text-align:center;}"
        ".folder-chip:hover{border-color:#f8fafc;}"
        ".folder-chip.active{box-shadow:0 0 0 2px #f8fafc;}"
        ".file-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(100px,1fr));grid-auto-rows:100px;gap:10px;margin:8px auto 0;width:100%;max-width:calc(8*100px + 7*10px);justify-content:center;}"
        ".track-card{border-radius:10px;width:100px;height:100px;display:flex;align-items:flex-end;justify-content:center;position:relative;overflow:hidden;color:#0b0d13;background:#111827;cursor:pointer;box-shadow:0 4px 12px rgba(0,0,0,0.35);border:3px solid transparent;z-index:1;transition:transform .15s ease,box-shadow .2s ease;}"
        ".track-card.playing{box-shadow:0 0 0 4px #3b82f6,0 0 30px rgba(59,130,246,0.9),0 0 60px rgba(59,130,246,0.35),inset 0 0 28px rgba(255,255,255,0.55);border-color:#3b82f6;z-index:3;transform:translateY(-3px);}"
        ".track-name{width:100%;text-align:center;padding:6px 4px;box-sizing:border-box;color:#0b0d13;font-weight:700;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:11px;text-shadow:0 1px 3px rgba(0,0,0,0.35);background:rgba(0,0,0,0.1);}"
        ".icon-btn{width:34px;height:34px;border:1px solid #1f2430;border-radius:8px;background:#0c0e12;color:#cbd5e1;display:inline-flex;align-items:center;justify-content:center;cursor:pointer;margin-left:12px;position:relative;}"
        ".icon-btn::before{content:'';display:block;width:14px;height:14px;}"
        ".icon-btn:hover{border-color:#3b82f6;color:#e5e7eb;}"
        ".icon-btn.active{border-color:#3b82f6;box-shadow:0 0 0 1px #3b82f6;background:#0e1220;color:#e5e7eb;}"
        ".icon-btn.icon-stop::before{width:12px;height:12px;background:#f87171;border-radius:3px;}"
        ".icon-btn.icon-pause::before{background:linear-gradient(90deg,#cbd5e1 0,#cbd5e1 40%,transparent 40%,transparent 60%,#cbd5e1 60%,#cbd5e1 100%);}"
        ".icon-btn.icon-play::before{content:'';width:0;height:0;border-left:12px solid #cbd5e1;border-top:6px solid transparent;border-bottom:6px solid transparent;margin-left:2px;}"
        ".icon-btn.icon-repeat::before{background-image:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' stroke='%23cbd5e1' stroke-width='2' fill='none' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpolyline points='17 1 21 5 17 9'/%3E%3Cpath d='M3 11V9a4 4 0 0 1 4-4h14'/%3E%3Cpolyline points='7 23 3 19 7 15'/%3E%3Cpath d='M21 13v2a4 4 0 0 1-4 4H3'/%3E%3C/svg%3E\");background-size:contain;background-repeat:no-repeat;}"
        ".robot-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(100px,1fr));grid-auto-rows:140px;grid-gap:12px;margin-top:12px;justify-content:center;max-width:calc(8*100px + 7*12px);margin-left:auto;margin-right:auto;}"
        ".robot-slot{display:flex;flex-direction:column;gap:6px;width:100px;align-items:center;}"
        ".robot-slot-label{font-size:12px;color:#8b92a3;align-self:flex-start;}"
        ".robot-card{cursor:pointer;position:relative;}"
        ".robot-edit-btn{position:absolute;top:4px;right:4px;width:26px;height:26px;border-radius:50%;border:1px solid rgba(0,0,0,0.2);background:rgba(255,255,255,0.2);color:#0b0d13;font-weight:bold;line-height:1;display:flex;align-items:center;justify-content:center;}"
        ".pic-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:10px;}"
        ".pic-card{border:1px solid #1f2430;border-radius:10px;background:#0c0e12;padding:12px;display:flex;flex-direction:column;gap:8px;overflow:hidden;}"
        ".pic-uids{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;}"
        ".pic-uids input{width:100%;box-sizing:border-box;min-width:0;}"
        ".pic-last{font-size:12px;color:#8b92a3;}"
        "table{width:100%;border-collapse:collapse;margin-top:10px;}"
        "td,th{border:1px solid #1f2430;padding:8px;}"
        "@media(max-width:600px){header{padding:12px;} .pane{padding:16px;width:100%;} .card{margin:0 0 12px;width:100%;} .hero{margin:0 0 12px;padding:12px;} .row{flex-direction:column;align-items:stretch;} .row button,.row select,.row input{width:100%;max-width:100%;} .controls-row{flex-direction:column;align-items:stretch;} .control-buttons{justify-content:space-between;} .volume-control{width:100%;} .progress-row input{max-width:100%;} .file-browser{padding:10px;} .file-grid{grid-template-columns:repeat(4,minmax(0,1fr));max-width:none;} .robot-grid{grid-template-columns:repeat(4,minmax(0,1fr));max-width:none;}}"
        "</style></head><body>"
        "<div class='page'>"
        "<header><div class='tabs'>"
        "<div class='tab active' data-tab='status' data-icon='status'><span class='tab-icon'></span><span class='tab-label'>Status</span></div>"
        "<div class='tab' data-tab='audio' data-icon='audio'><span class='tab-icon'></span><span class='tab-label'>Audio</span></div>"
        "<div class='tab' data-tab='pictures' data-icon='pictures'><span class='tab-icon'></span><span class='tab-label'>Pictures</span></div>"
        "<div class='tab' data-tab='laser' data-icon='laser'><span class='tab-icon'></span><span class='tab-label'>Laser</span></div>"
        "<div class='tab' data-tab='robot' data-icon='robot'><span class='tab-icon'></span><span class='tab-label'>Robot</span></div>"
        "<div class='tab' data-tab='settings' data-icon='settings'><span class='tab-icon'></span><span class='tab-label'>Settings</span></div>"
        "</div></header>"
        "<div class='hero'><h2>Broker</h2><div class='status-clusters'>"
        "<div class='device-cluster'><span class='label'>🖼️ Pictures</span><span id='cluster_pictures' class='dots'></span></div>"
        "<div class='device-cluster'><span class='label'>🔫 Laser</span><span id='cluster_laser' class='dots'></span></div>"
        "<div class='device-cluster'><span class='label'>🤖 Robot</span><span id='cluster_robot' class='dots'></span></div>"
        "</div><div id='banner' class='muted'>Loading status...</div></div>"
        "<div class='pane active' id='pane-status'>"
        "<div class='card'><h3>Status<span id='status_badge' class='badge'></span></h3>"
        "<div class='status-row'><button onclick='ping()'>Ping</button><button onclick='loadStatus()'>Refresh</button><button id='status_raw_btn' onclick='toggleRaw()'>Show raw</button><span id='status_state' class='muted'>Loading...</span></div>"
        "<div class='stat-grid'>"
        "<div class='stat'><span class='label'>Wi-Fi SSID</span><span id='status_ssid' class='value'>n/a</span></div>"
        "<div class='stat'><span class='label'>STA IP</span><span id='status_ip' class='value'>n/a</span></div>"
        "<div class='stat'><span class='label'>SD Size</span><span id='status_sd_size' class='value'>n/a</span></div>"
        "<div class='stat'><span class='label'>Clients total</span><span id='status_clients' class='value'>0</span></div>"
        "</div>"
        "<pre id='status_raw' class='muted small' style='display:none;'></pre>"
        "</div></div>"

        "<div class='pane' id='pane-audio'>"
        "<div class='card'><h3>Audio</h3>"
        "<input id='audio_path' type='hidden'>"
        "<div class='controls-row'><div class='volume-control'><input id='audio_vol' type='range' min='0' max='100' value='70' oninput=\"volInput(this.value)\"><span class='muted'>Volume: <span id='audio_vol_val'>70</span>%</span></div><div class='control-buttons'><button id='audio_repeat_btn' class='icon-btn icon-repeat' onclick='toggleRepeat()' title='Repeat track'></button><button id='audio_pause_btn' class='icon-btn icon-pause' onclick='togglePause()' title='Pause'></button><button id='audio_stop_btn' class='icon-btn icon-stop' onclick='stopPlay()' title='Stop'></button></div></div>"
        "<div class='progress-box'><div class='row progress-row'><input id='audio_prog' type='range' min='0' max='10000' value='0' step='1' oninput=\"scrubPreview(this.value)\" onchange=\"commitScrub(this.value)\" onmousedown=\"startScrub()\" onmouseup=\"finishScrub()\" ontouchstart=\"startScrub()\" ontouchend=\"finishScrub()\" ontouchcancel=\"finishScrub()\"><span class='muted'>Progress: <span id='audio_prog_txt'>0:00 / ?</span></span></div></div>"
        "<div id='audio_status' class='muted small'>Loading files...</div>"
        "<div class='file-browser'>"
        "<div class='row'><button onclick='navUp()'>Up</button><button onclick='loadFiles()'>Refresh files</button><span id='path_label' class='muted small'>/sdcard</span><span class='muted small'>Click track to select</span></div>"
        "<div id='audio_folders' class='folder-row' style='border:1px solid #1f2430;padding:6px 10px;border-radius:12px;background:#0d1018;margin-top:8px;min-height:50px;'></div>"
        "<div id='audio_files' class='file-grid' style='border:1px solid #1f2430;padding:10px;border-radius:12px;background:#0d1018;margin-top:8px;'></div>"
        "</div>"
        "</div></div>"

        "<div class='pane' id='pane-pictures'>"
        "<div class='card'><h3>Pictures setup</h3>"
        "<div class='row'><button onclick='loadPictures()'>Refresh</button><button onclick='saveTracks()'>Save tracks</button><button onclick='toggleAddMode(true)'>Add mode ON</button><button onclick='toggleAddMode(false)'>Add mode OFF</button><button onclick='forceCheck()'>Force check</button></div>"
        "<div class='row'><select id='track_ok_select'></select><select id='track_fail_select'></select></div>"
        "<div id='pic_status' class='muted small'></div>"
        "<div id='pic_grid' class='pic-grid'></div>"
        "</div></div>"

        "<div class='pane' id='pane-laser'>"
        "<div class='card'><h3>Laser</h3>"
        "<div class='row'><button onclick='loadLaser()'>Refresh</button><button onclick='saveLaser()'>Save</button></div>"
        "<div class='row'><button id='laser_toggle_btn' onclick='toggleLaser()'>Disable</button><span id='laser_toggle_status' class='muted small'></span></div>"
        "<div class='row'><select id='laser_hold_select'></select><select id='laser_relay_select'></select></div>"
        "<div class='row'><input id='laser_seconds' type='number' min='1' max='3600' value='20' style='max-width:160px' placeholder='Hold seconds'><select id='laser_mode' style='max-width:220px'><option value='cumulative'>Накопительный</option><option value='continuous'>Непрерывный</option></select></div>"
        "<div id='laser_status' class='muted small'></div>"
        "<div class='muted small'>Трек удержания играет пока есть heartbeat laser/laserOn, при пропадании ставится на паузу. Порог включает relay/relayOn и отправляет robot/laser/relayOn.mp3.</div>"
        "</div></div>"

        "<div class='pane' id='pane-robot'>"
        "<div class='card'>"
        "<div class='row mode-row'><button id='sarcasm_btn' class='mode-btn' onclick='toggleSarcasm()'>Sarcastic</button><button id='broken_btn' class='mode-btn' onclick='toggleBroken()'>Broken</button></div>"
        "<div class='card' style='margin-top:12px;'>"
        "<h4>Quick tracks</h4>"
        "<div class='muted small'>Tap a tile to publish /sdcard/audio/&lt;name&gt;.mp3. Use + to edit the slot.</div>"
        "<div id='robot_presets' class='robot-grid'></div>"
        "</div>"
        "<div class='card' style='margin-top:12px;'>"
        "<h4>Robot folders</h4>"
        "<div class='row'><input id='robot_laser_dir' placeholder='robot/laser dir' style='min-width:220px'><input id='robot_sarcasm_dir' placeholder='robot/mode/sarcastic dir' style='min-width:220px'><input id='robot_broken_dir' placeholder='robot/broken dir' style='min-width:220px'></div>"
        "<div class='row'><button onclick='saveRobotCfg()'>Save</button></div>"
        "<div id='robot_status' class='muted small'></div>"
        "</div>"
        "</div></div>"

        "<div class='pane' id='pane-settings'>"
        "<div class='card'><h3>Settings</h3>"
        "<div class='row'><input id='ssid' placeholder='SSID'><input id='pass' placeholder='Password'><input id='host' placeholder='Hostname'></div>"
        "<button onclick='saveWifi()'>Save Wi-Fi</button>"
        "<button onclick='scanWifi()'>Scan</button>"
        "<div id='wifi_list' class='list'></div>"
        "<div class='muted'>If AP is up: password 12345678.</div>"
        "</div>"
        "<div class='card'><h3>MQTT</h3>"
        "<div class='row'><input id='mqtt_id' placeholder='Broker ID'><input id='mqtt_port' placeholder='Port' style='max-width:140px'><input id='mqtt_keep' placeholder='Keepalive s' style='max-width:160px'></div>"
        "<button onclick='saveMqtt()'>Save</button>"
        "</div>"
        "<div class='card'><h3>Publish MQTT</h3>"
        "<div class='row'><input id='pub_topic' placeholder='topic'><input id='pub_payload' placeholder='payload'></div>"
        "<button onclick='publishMsg()'>Send</button>"
        "</div>"
        "</div>"

        "<script>"
        "const tabs=document.querySelectorAll('.tab');const panes=document.querySelectorAll('.pane');"
        "const tabIconDefaults=['status','audio','pictures','laser','robot','settings','network','power'];"
        "tabs.forEach((tab,idx)=>{if(!tab.dataset.icon){tab.dataset.icon=tabIconDefaults[idx%tabIconDefaults.length];}});"
        "const loadedTabs={status:true,audio:false,pictures:false,laser:false,robot:false};"
        "const ROBOT_PRESET_COUNT=8;let robotPresets=new Array(ROBOT_PRESET_COUNT).fill('');"
        "tabs.forEach(t=>t.onclick=()=>{tabs.forEach(x=>x.classList.remove('active'));panes.forEach(p=>p.classList.remove('active'));t.classList.add('active');document.getElementById('pane-'+t.dataset.tab).classList.add('active');ensureTabLoaded(t.dataset.tab);});"
        "function ensureTabLoaded(tab){switch(tab){case 'audio':if(!loadedTabs.audio){loadFiles().then(()=>{loadedTabs.audio=true;}).catch(()=>{});}break;case 'pictures':if(!loadedTabs.pictures){loadFiles().then(()=>loadPictures()).then(()=>{loadedTabs.pictures=true;}).catch(()=>{});}break;case 'laser':if(!loadedTabs.laser){loadFiles().then(()=>loadLaser()).then(()=>{loadedTabs.laser=true;}).catch(()=>{});}break;case 'robot':if(!loadedTabs.robot){Promise.all([loadRobot(),loadRobotPresets()]).finally(()=>{loadedTabs.robot=true;});}break;default:break;}}"
        "function ping(){fetch('/api/ping').then(r=>r.text()).then(alert);} "
        "let apPopupShown=false;"
        "function updateBanner(j){const b=document.getElementById('banner');const badge=document.getElementById('status_badge');const ap=j.wifi.ap;const ip=j.wifi.sta_ip;badge.textContent=ap?'AP+STA':'STA';badge.style.background=ap?'#f97316':'#1f2430';if(ap){b.textContent='Setup mode: AP+STA, will disable AP after connect.';}else{b.textContent='Connected to '+j.wifi.ssid+' IP '+(ip||'none');}}"
        "function setTxt(id,v){const el=document.getElementById(id);if(el){el.textContent=v;}}"
        "function renderDots(id,count,max){const el=document.getElementById(id);if(!el)return;el.innerHTML='';for(let i=0;i<max;i++){const dot=document.createElement('span');dot.style.background=i<count?'#22c55e':'#1f2937';el.appendChild(dot);}}"
        "function humanMb(bytes){if(!bytes||bytes<=0)return'-';return (bytes/1024/1024).toFixed(1)+' MB';}"
        "function humanGb(bytes){if(!bytes||bytes<=0)return'0 GB';return (bytes/(1024*1024*1024)).toFixed(2)+' GB';}"
        "function renderStatus(j){setTxt('status_raw',JSON.stringify(j,null,2));setTxt('status_ssid',j.wifi.ssid||'n/a');setTxt('status_ip',j.wifi.sta_ip||'none');const sd=j.sd||{};if(sd.ok){setTxt('status_sd_size',`${humanGb(sd.total)} / free ${humanGb(sd.free)}`);}else{setTxt('status_sd_size','No card');}setTxt('status_clients',j.clients?j.clients.total:0);renderDots('clients_pictures',j.clients?j.clients.pictures:0,5);renderDots('clients_laser',j.clients?j.clients.laser:0,2);renderDots('clients_robot',j.clients?j.clients.robot:0,1);const picDots=document.getElementById('cluster_pictures');const laserDots=document.getElementById('cluster_laser');const robotDots=document.getElementById('cluster_robot');if(picDots){picDots.innerHTML='';renderDots('cluster_pictures',j.clients?j.clients.pictures:0,5);}if(laserDots){laserDots.innerHTML='';renderDots('cluster_laser',j.clients?j.clients.laser:0,2);}if(robotDots){robotDots.innerHTML='';renderDots('cluster_robot',j.clients?j.clients.robot:0,1);}}"
        "let rawShown=false;"
        "function toggleRaw(){rawShown=!rawShown;const pre=document.getElementById('status_raw');const btn=document.getElementById('status_raw_btn');if(pre){pre.style.display=rawShown?'block':'none';}if(btn){btn.textContent=rawShown?'Hide raw':'Show raw';}}"
        "function loadStatus(){setTxt('status_state','Loading...');fetch('/api/status').then(r=>{if(!r.ok)throw new Error('HTTP '+r.status);return r.json();}).then(j=>{renderStatus(j);setTxt('status_state','Updated');document.getElementById('ssid').value=j.wifi.ssid;document.getElementById('host').value=j.wifi.host;document.getElementById('mqtt_id').value=j.mqtt.id;document.getElementById('mqtt_port').value=j.mqtt.port;document.getElementById('mqtt_keep').value=j.mqtt.keepalive;updateAudioFromStatus(j.audio||{});updateBanner(j);if(j.wifi.sta_ip && j.wifi.sta_ip.length>0 && j.wifi.ap && !apPopupShown){apPopupShown=true;alert('Connected. IP: '+j.wifi.sta_ip+'\\nDisabling AP.');fetch('/api/ap/stop');}}).catch(err=>{setTxt('status_state','Failed to load');setTxt('status_raw',err.message);});}"
        "function saveWifi(){const s=ssid.value,p=pass.value,h=host.value;fetch(`/api/config/wifi?ssid=${encodeURIComponent(s)}&password=${encodeURIComponent(p)}&host=${encodeURIComponent(h)}`).then(r=>r.text()).then(alert);}"
        "function scanWifi(){fetch('/api/wifi/scan').then(r=>r.json()).then(list=>{const c=document.getElementById('wifi_list');c.innerHTML='';list.forEach(name=>{const d=document.createElement('div');d.className='pill';d.textContent=name;d.onclick=()=>{ssid.value=name;};c.appendChild(d);});});}"
        "function saveMqtt(){const id=mqtt_id.value,port=mqtt_port.value,keep=mqtt_keep.value;fetch(`/api/config/mqtt?id=${encodeURIComponent(id)}&port=${port}&keepalive=${keep}`).then(r=>r.text()).then(alert);}"
        "const PROGRESS_MAX=10000;"
        "const SEEK_DEBOUNCE_MS=150;"
        "const SEEK_ACK_THRESHOLD=50;"
        "const SEEK_MAX_HOLD_MS=2000;"
        "let audioPlaying=false;"
        "let audioPaused=false;"
        "let currentPlayingPath='';"
        "let lastPlayedPath='';"
        "let pendingTrackPath='';"
        "let repeatOne=false;"
        "let repeatInFlight=false;"
        "let progressScrubbing=false;"
        "let seekTimer=null;"
        "let pendingSeekValue=null;"
        "let seekPending=false;"
        "let seekReleaseTimer=null;"
        "let seekAwaitValue=null;"
        "function play(path){const p=path||audio_path.value; if(!p){alert('Select a track');return;}"
        " setFileStatus('Playing...',false);"
        " resetProgressUI(true);"
        " pendingTrackPath=p;"
        " lastPlayedPath=p;"
        " repeatInFlight=false;"
        " const start=()=>fetch(`/api/audio/play?path=${encodeURIComponent(p)}&volume=${audio_vol.value}`).then(r=>r.text()).then(()=>{audioPlaying=true;audioPaused=false;currentPlayingPath=p;setFileStatus('Playing',false);markPlayingCard();}).catch(()=>setFileStatus('Play failed',true));"
        " if(currentPlayingPath){fetch('/api/audio/stop').catch(()=>{}).finally(()=>{start();});}else{start();}"
        "}"
        "function pauseAudio(){fetch('/api/audio/pause').then(()=>{audioPaused=true;setFileStatus('Paused',false);updatePauseBtn();}).catch(()=>setFileStatus('Pause failed',true));}"
        "function resumeAudio(){fetch('/api/audio/resume').then(()=>{audioPaused=false;setFileStatus('Playing',false);updatePauseBtn();}).catch(()=>setFileStatus('Resume failed',true));}"
        "function togglePause(){if(audioPaused){resumeAudio();}else{pauseAudio();}}"
        "function updatePauseBtn(){const btn=document.getElementById('audio_pause_btn');if(!btn)return;btn.title=audioPaused?'Resume':'Pause';if(audioPaused){btn.classList.add('icon-play');btn.classList.remove('icon-pause');}else{btn.classList.add('icon-pause');btn.classList.remove('icon-play');}}"
        "function stopPlay(){fetch('/api/audio/stop').then(()=>{audioPlaying=false;audioPaused=false;currentPlayingPath='';lastPlayedPath='';pendingTrackPath='';repeatInFlight=false;markPlayingCard();setFileStatus('Stopped',false);resetProgressUI(true);updatePauseBtn();}).catch(()=>setFileStatus('Stop failed',true));}"
        "function setVolume(v){volInput(v);}"
        "function publishMsg(){fetch(`/api/publish?topic=${encodeURIComponent(pub_topic.value)}&payload=${encodeURIComponent(pub_payload.value)}`).then(r=>r.text());}"
        "let filesData=[];"
        "let currentDir='/sdcard';"
        "let rootDirs=[];"
        "let picturesConfig=null;"
        "function ensureTrackOption(sel,value){if(!sel||!value)return;let exists=false;Array.from(sel.options||[]).forEach(o=>{if(o.value===value)exists=true;});if(!exists){const opt=document.createElement('option');opt.value=value;opt.textContent=value.split('/').pop();sel.appendChild(opt);}sel.value=value;}"
        "function applyPicSelections(cfg){if(!cfg)return;ensureTrackOption(document.getElementById('track_ok_select'),cfg.ok);ensureTrackOption(document.getElementById('track_fail_select'),cfg.fail);}"
        "const playPalette=['#d8b4fe','#c084fc','#5eead4','#22d3ee','#fdba74','#fb923c','#fcd34d','#fde68a'];"
        "function colorForIndex(idx){return playPalette[idx%playPalette.length];}"
        "function adjustColor(hex,amount){if(!hex)return'#000000';let c=hex.replace('#','');if(c.length===3){c=c.split('').map(ch=>ch+ch).join('');}const num=parseInt(c,16);if(isNaN(num))return hex;const clamp=v=>Math.min(255,Math.max(0,v));const r=clamp((num>>16)+amount);const g=clamp(((num>>8)&0xFF)+amount);const b=clamp((num&0xFF)+amount);const toHex=v=>v.toString(16).padStart(2,'0');return `#${toHex(r)}${toHex(g)}${toHex(b)}`;}"
        "function stylePad(el,idx){const c=colorForIndex(idx);const lighter=adjustColor(c,70);const darker=adjustColor(c,-30);el.style.backgroundColor=c;el.style.backgroundImage=`linear-gradient(135deg, ${lighter}, ${darker})`;el.style.boxShadow='0 6px 14px rgba(0,0,0,0.35)';}"
        "function tintTabs(){tabs.forEach((tab,idx)=>{const c=colorForIndex(idx);const lighter=adjustColor(c,70);const darker=adjustColor(c,-30);tab.style.setProperty('--tab-color',c);tab.style.backgroundColor=c;tab.style.backgroundImage=`linear-gradient(135deg, ${lighter}, ${darker})`;tab.style.borderColor=darker;});}"
        "tintTabs();"
        "function truncateName(name,max=16){if(!name)return'';return name.length>max?name.slice(0,max-3)+'...':name;}"
        "let volTimer=null;let volPending=null;"
        "function sendVolumeNow(v){fetch(`/api/audio/volume?val=${v}`).catch(()=>{});}"
        "function volInput(v){audio_vol_val.textContent=v;volPending=v;if(volTimer){return;}volTimer=setTimeout(()=>{if(volPending!==null){sendVolumeNow(volPending);}volPending=null;volTimer=null;},150);}"
        "function setFileStatus(msg,isError){const els=[document.getElementById('audio_status')];els.forEach(el=>{if(el){el.textContent=msg||'';el.style.color=isError?'#f87171':'#8b92a3';}});}"
        "function humanSize(bytes){if(!bytes||bytes<=0)return'-';const kb=1024,mb=kb*1024;if(bytes>=mb)return (bytes/mb).toFixed(1)+' MB';return Math.round(bytes/kb)+' KB';}"
        "function formatTime(ms){if(!ms||ms<=0)return'0:00';const totalSeconds=Math.floor(ms/1000);const minutes=Math.floor(totalSeconds/60);const seconds=(totalSeconds%60).toString().padStart(2,'0');return `${minutes}:${seconds}`;}"
        "let currentBitrateKbps=0;"
        "let lastProgressLabel='';"
        "function markPlayingCard(){const cards=document.querySelectorAll('.track-card');cards.forEach(c=>{const p=c.dataset.path||'';if(currentPlayingPath&&p===currentPlayingPath){c.classList.add('playing');}else{c.classList.remove('playing');}});}"
        "function resetProgressUI(disable){if(disable===undefined)disable=true;if(seekTimer){clearTimeout(seekTimer);seekTimer=null;}if(seekReleaseTimer){clearTimeout(seekReleaseTimer);seekReleaseTimer=null;}pendingSeekValue=null;seekAwaitValue=null;seekPending=false;progressScrubbing=false;const prog=document.getElementById('audio_prog');if(prog){prog.value=0;if(disable){prog.disabled=true;}delete prog.dataset.dur_ms;}const progTxt=document.getElementById('audio_prog_txt');if(progTxt){lastProgressLabel='0:00 / ?';progTxt.textContent=lastProgressLabel;}}"
        "function clampProgressValue(value){const num=Number(value);if(isNaN(num))return 0;return Math.min(Math.max(Math.round(num),0),PROGRESS_MAX);}"
        "function progressFraction(value){return clampProgressValue(value)/PROGRESS_MAX;}"
        "function scheduleSeek(value){pendingSeekValue=clampProgressValue(value);if(seekTimer){return;}seekTimer=setTimeout(()=>{seekTimer=null;if(pendingSeekValue===null)return;seekAudio(pendingSeekValue);pendingSeekValue=null;},SEEK_DEBOUNCE_MS);}"
        "function holdSeekPosition(value){seekPending=true;seekAwaitValue=clampProgressValue(value);if(seekReleaseTimer){clearTimeout(seekReleaseTimer);}seekReleaseTimer=setTimeout(()=>{seekPending=false;seekReleaseTimer=null;seekAwaitValue=null;},SEEK_MAX_HOLD_MS);}"
        "function releaseSeekHold(){if(seekReleaseTimer){clearTimeout(seekReleaseTimer);seekReleaseTimer=null;}seekPending=false;seekAwaitValue=null;}"
        "function failSeek(msg){releaseSeekHold();if(msg){setFileStatus(msg,true);}}"
        "function startScrub(){progressScrubbing=true;}"
        "function finishScrub(){progressScrubbing=false;}"
        "function commitScrub(value){finishScrub();holdSeekPosition(value);scheduleSeek(value);}"
        "function seekAudio(value){if(!(audioPlaying||audioPaused)){failSeek();return;}const prog=document.getElementById('audio_prog');if(!prog||!prog.dataset.dur_ms){failSeek('Cannot seek right now');return;}const dur=parseInt(prog.dataset.dur_ms,10);if(!dur||dur<=0){failSeek('Cannot seek: unknown duration');return;}const frac=progressFraction(value);const target=Math.floor(dur*frac);fetch(`/api/audio/seek?pos=${target}`).then(r=>{if(!r.ok)throw new Error('seek');return r.text();}).catch(()=>failSeek('Seek failed'));}"
        "function scrubPreview(value){progressScrubbing=true;if(!(audioPlaying||audioPaused))return;const progTxt=document.getElementById('audio_prog_txt');const prog=document.getElementById('audio_prog');if(!prog||!progTxt||!prog.dataset.dur_ms)return;const dur=parseInt(prog.dataset.dur_ms,10);if(!dur||dur<=0)return;const frac=progressFraction(value);const preview=formatTime(Math.floor(dur*frac));const full=formatTime(dur);progTxt.textContent=`${preview} / ${full}`;}"
        "function updateAudioFromStatus(a){if(!a)a={};const statusPath=a.path||'';const progressLocked=pendingTrackPath&&a.playing&&statusPath!==pendingTrackPath;const vol=document.getElementById('audio_vol');const volVal=document.getElementById('audio_vol_val');if(vol){vol.value=a.volume||a.audio_volume||vol.value;if(volVal){volVal.textContent=vol.value;}}const prog=document.getElementById('audio_prog');const progTxt=document.getElementById('audio_prog_txt');if(prog){if(a.dur_ms){prog.dataset.dur_ms=a.dur_ms;}let sliderVal=0;if(a.progress!==undefined&&a.progress!==null){const raw=a.progress<=1?Math.round(a.progress*PROGRESS_MAX):Math.round(a.progress*100);sliderVal=clampProgressValue(raw);}if(seekPending&&seekAwaitValue!==null){const delta=Math.abs(sliderVal-seekAwaitValue);if(delta<=SEEK_ACK_THRESHOLD){releaseSeekHold();}}if(!progressScrubbing&&!seekPending&&!progressLocked){prog.value=sliderVal;}const sliderEnabled=(a.playing||a.paused)&&!progressLocked;prog.disabled=!sliderEnabled;}if(progTxt&&!progressScrubbing&&!seekPending&&!progressLocked){const posLabel=formatTime(a.pos_ms);const durLabel=a.dur_ms&&a.dur_ms>0?formatTime(a.dur_ms):'?';const combined=`${posLabel} / ${durLabel}`;if(combined!==lastProgressLabel){progTxt.textContent=combined;lastProgressLabel=combined;}}const st=document.getElementById('audio_status');if(st){if(a.playing){st.textContent=`Playing: ${statusPath}${a.paused?' (paused)':''}`;}else if(a.message){st.textContent=`${a.message}${statusPath?' '+statusPath:''}`;}else if(statusPath){st.textContent=`Ready: ${statusPath}`;}else{st.textContent='Idle';}}if(a.playing){if(pendingTrackPath&&statusPath===pendingTrackPath){pendingTrackPath=''; currentPlayingPath=statusPath||currentPlayingPath;}else if(!pendingTrackPath&&statusPath){currentPlayingPath=statusPath;}}else if(!a.paused){pendingTrackPath='';currentPlayingPath='';}audioPlaying=!!a.playing;audioPaused=!!a.paused;if(a.playing&&statusPath){lastPlayedPath=statusPath;}if(a.playing){repeatInFlight=false;}currentBitrateKbps=a.bitrate||0;markPlayingCard();updatePauseBtn();if(repeatOne&&!a.playing&&lastPlayedPath&&!repeatInFlight){repeatInFlight=true;play(lastPlayedPath);}}"
        "function setPathLabel(){const lbl=document.getElementById('path_label');if(lbl){lbl.textContent=currentDir;}}"
        "function enterDir(path){currentDir=path||'/sdcard';setPathLabel();loadFiles();}"
        "function navUp(){if(!currentDir||currentDir==='/sdcard'){return;}const parts=currentDir.split('/');parts.pop();if(parts.length<2){currentDir='/sdcard';}else{currentDir=parts.join('/');}setPathLabel();loadFiles();}"
        "function renderFolders(dirs,currentDirs){const bar=document.getElementById('audio_folders');if(!bar)return;bar.innerHTML='';const seen=new Set();let idx=0;const addChip=(d)=>{if(!d||!d.path)return;const key=d.path;if(seen.has(key))return;seen.add(key);const chip=document.createElement('div');chip.className='folder-chip';chip.style.borderColor=colorForIndex(idx);chip.onclick=()=>enterDir(d.path);if(currentDir===d.path){chip.classList.add('active');}chip.textContent=truncateName(d.name||d.path);chip.title=d.path;bar.appendChild(chip);idx++;};(dirs||[]).forEach(addChip);(currentDirs||[]).forEach(addChip);}"
        "function renderFiles(list){filesData=list||[];const audioBox=document.getElementById('audio_files');if(audioBox){audioBox.innerHTML='';}"
         " if(!list||list.length===0){[audioBox].forEach(c=>{if(!c)return;const empty=document.createElement('div');empty.className='muted small';empty.textContent='No files';c.appendChild(empty);});return;}"
         " const okSel=document.getElementById('track_ok_select');const failSel=document.getElementById('track_fail_select');const lHold=document.getElementById('laser_hold_select');const lRelay=document.getElementById('laser_relay_select');[okSel,failSel,lHold,lRelay].forEach(sel=>{if(sel){sel.innerHTML='<option value=\"\">-- track --</option>';}});"
         " const dirs=[];"
         " let padIdx=0;"
         " list.forEach(f=>{const path=f.path||f;const size=f.size||0;const dur=f.dur||0;"
        "   if(f.dir){dirs.push({path, name:path.split('/').pop()||path});return;}"
        "   if(audioBox){const card=document.createElement('div');card.className='track-card';card.dataset.path=path;stylePad(card,padIdx++);card.onclick=()=>{audio_path.value=path;play(path);};"
        "     const name=document.createElement('div');name.className='track-name';name.textContent=path.split('/').pop();card.appendChild(name);"
        "     audioBox.appendChild(card);}"
        "   [okSel,failSel,lHold,lRelay].forEach(sel=>{if(sel){const opt=document.createElement('option');opt.value=path;opt.textContent=path.split('/').pop();sel.appendChild(opt);}});"
         " });"
        " if(picturesConfig){applyPicSelections(picturesConfig);}"
        " renderFolders(rootDirs.length?rootDirs:dirs, dirs);"
        " markPlayingCard();}"
        "function loadRobot(){return fetch('/api/robot/config').then(r=>{if(!r.ok)throw new Error('robot');return r.json();}).then(cfg=>{const laser=document.getElementById('robot_laser_dir');const sarc=document.getElementById('robot_sarcasm_dir');const broken=document.getElementById('robot_broken_dir');if(laser){laser.value=cfg.laser||'';}if(sarc){sarc.value=cfg.sarcastic||'';}if(broken){broken.value=cfg.broken||'';}const st=document.getElementById('robot_status');if(st){st.textContent='Loaded';}return cfg;}).catch(()=>{});}"
        "function saveRobotCfg(){const laser=document.getElementById('robot_laser_dir').value||'';const sarc=document.getElementById('robot_sarcasm_dir').value||'';const broken=document.getElementById('robot_broken_dir').value||'';const st=document.getElementById('robot_status');const url=`/api/robot/save?laser=${encodeURIComponent(laser)}&sarcastic=${encodeURIComponent(sarc)}&broken=${encodeURIComponent(broken)}`;fetch(url).then(r=>r.text()).then(()=>{if(st){st.textContent='Saved';}}).catch(()=>{if(st){st.textContent='Save failed';}});}"
        "function publishSarcasm(){const dir=document.getElementById('robot_sarcasm_dir').value||'';if(!dir){alert('Select sarcastic folder');return;}fetch(`/api/publish?topic=${encodeURIComponent('robot/mode/sarcastic')}&payload=${encodeURIComponent(dir)}`).then(()=>{const st=document.getElementById('robot_status');if(st){st.textContent='Sent sarcastic';}}).catch(()=>{});}"
        "const MODE_EXIT_DELAY_MS=800;"
        "let sarcasmOn=false;"
        "let brokenOn=false;"
        "let modeLast='';"
        "let modeBusy=false;"
        "function delayMs(ms){return new Promise(resolve=>setTimeout(resolve,ms));}"
        "function refreshModeButtons(){const sarc=document.getElementById('sarcasm_btn');const broken=document.getElementById('broken_btn');[sarc,broken].forEach(btn=>{if(btn){btn.disabled=modeBusy;}});if(sarc){sarc.classList.toggle('active',sarcasmOn);sarc.classList.toggle('mode-last',modeLast==='sarcasm');}if(broken){broken.classList.toggle('active',brokenOn);broken.classList.toggle('mode-last',modeLast==='broken');}}"
        "function setModeLast(name){modeLast=name||'';refreshModeButtons();}"
        "function setSarcasm(on){return fetch(`/api/publish?topic=${encodeURIComponent('robot/mode/sarcastic')}&payload=${encodeURIComponent(on?'on':'off')}`).then(()=>{sarcasmOn=on;if(on){setModeLast('sarcasm');}else if(!brokenOn){setModeLast('');}refreshModeButtons();});}"
        "function setBroken(on){const dir=document.getElementById('robot_broken_dir').value||'';if(on&&!dir){alert('Enter broken folder');return Promise.reject(new Error('missing broken dir'));}const topic=on?'robot/broken/on':'robot/broken/off';const payload=on?dir:'off';return fetch(`/api/publish?topic=${encodeURIComponent(topic)}&payload=${encodeURIComponent(payload)}`).then(()=>{brokenOn=on;if(on){setModeLast('broken');}else if(!sarcasmOn){setModeLast('');}refreshModeButtons();});}"
        "function ensureBrokenOff(){if(!brokenOn)return Promise.resolve();return setBroken(false).then(()=>delayMs(MODE_EXIT_DELAY_MS));}"
        "function ensureSarcasmOff(){if(!sarcasmOn)return Promise.resolve();return setSarcasm(false).then(()=>delayMs(MODE_EXIT_DELAY_MS));}"
        "function toggleSarcasm(){const next=!sarcasmOn;if(modeBusy)return;modeBusy=true;refreshModeButtons();(next?ensureBrokenOff():Promise.resolve()).then(()=>setSarcasm(next)).catch(()=>{}).finally(()=>{modeBusy=false;refreshModeButtons();});}"
        "function toggleBroken(){const next=!brokenOn;if(modeBusy)return;modeBusy=true;refreshModeButtons();(next?ensureSarcasmOff():Promise.resolve()).then(()=>setBroken(next)).catch(()=>{}).finally(()=>{modeBusy=false;refreshModeButtons();});}"
        "function renderRobotPresets(){const grid=document.getElementById('robot_presets');if(!grid)return;grid.innerHTML='';for(let i=0;i<ROBOT_PRESET_COUNT;i++){const slot=document.createElement('div');slot.className='robot-slot';const label=document.createElement('div');label.className='robot-slot-label';label.textContent=`Slot ${i+1}`;slot.appendChild(label);const card=document.createElement('div');card.className='track-card robot-card';stylePad(card,i);card.onclick=()=>playPreset(i);card.title='Play preset';const edit=document.createElement('button');edit.className='robot-edit-btn';edit.textContent='+';edit.title='Edit preset';edit.onclick=ev=>{ev.stopPropagation();editPreset(i);};card.appendChild(edit);const name=document.createElement('div');name.className='track-name';name.textContent=robotPresets[i]||'Empty';card.appendChild(name);slot.appendChild(card);grid.appendChild(slot);}}"
        "function loadRobotPresets(){return fetch('/api/robot/presets').then(r=>{if(!r.ok)throw new Error('preset');return r.json();}).then(arr=>{robotPresets=new Array(ROBOT_PRESET_COUNT).fill('');(arr||[]).forEach((n,idx)=>{if(idx<ROBOT_PRESET_COUNT){robotPresets[idx]=n||'';}});renderRobotPresets();}).catch(()=>{renderRobotPresets();});}"
        "function editPreset(idx){const current=robotPresets[idx]||'';const name=prompt('Track name (without .mp3)', current);if(name===null)return;const clean=(name||'').trim();fetch(`/api/robot/preset_set?idx=${idx}&name=${encodeURIComponent(clean)}`).then(()=>{robotPresets[idx]=clean;renderRobotPresets();}).catch(()=>{});}"
        "function playPreset(idx){const name=robotPresets[idx];if(!name){alert('Slot is empty');return;}fetch(`/api/robot/preset_play?idx=${idx}`).catch(()=>{});}"
        "function loadRootFolders(){return fetch('/api/files?path=/sdcard').then(r=>{if(!r.ok)throw new Error('sd');return r.json();}).then(list=>{rootDirs=(list||[]).filter(x=>x.dir).map(x=>({path:x.path,name:x.path.split('/').pop()||x.path}));}).catch(()=>{rootDirs=[];});}"
        "function loadFiles(){setFileStatus('Loading files...');setPathLabel();const url=`/api/files?path=${encodeURIComponent(currentDir)}`;const ensureRoot=currentDir==='/sdcard'?loadRootFolders():Promise.resolve();return ensureRoot.then(()=>fetch(url)).then(r=>{if(!r.ok)throw new Error('sd');return r.json();}).then(list=>{renderFiles(list);setFileStatus(list.length?'Choose a file to play':'No audio files found',false);return list;}).catch(err=>{renderFiles([]);setFileStatus('SD error',true);throw err;});}"
        "function renderPicGrid(cfg){const grid=document.getElementById('pic_grid');if(!grid)return;grid.innerHTML='';const status=document.getElementById('pic_status');if(status){status.textContent='';}"
        "cfg.devices.forEach(d=>{const card=document.createElement('div');card.className='pic-card';const title=document.createElement('div');title.innerHTML=`<strong>ESP ${d.idx}</strong>`;card.appendChild(title);const last=document.createElement('div');last.className='pic-last';last.textContent='Last: '+(d.last||'-');card.appendChild(last);"
        "const wrap=document.createElement('div');wrap.className='pic-uids';for(let i=0;i<10;i++){const inp=document.createElement('input');inp.placeholder='UID';inp.value=d.uids[i]||'';inp.dataset.idx=d.idx;inp.dataset.pos=i;wrap.appendChild(inp);}card.appendChild(wrap);"
        "const actions=document.createElement('div');actions.className='track-actions';const save=document.createElement('button');save.textContent='Save';save.onclick=()=>saveDevice(d.idx);const clear=document.createElement('button');clear.textContent='Clear';clear.onclick=()=>{wrap.querySelectorAll('input').forEach(inp=>inp.value='');saveDevice(d.idx);};actions.appendChild(save);actions.appendChild(clear);card.appendChild(actions);grid.appendChild(card);});"
        "picturesConfig=cfg;applyPicSelections(cfg);}"
        "function collectUids(idx){const inputs=document.querySelectorAll(`.pic-card input[data-idx='${idx}']`);const uids=[];inputs.forEach(inp=>{if(inp.value.trim().length>0)uids.push(inp.value.trim());});return uids.join(',');}"
        "function saveDevice(idx){const u=collectUids(idx);fetch(`/api/pictures/device/save?idx=${idx}&uids=${encodeURIComponent(u)}`).then(r=>r.text()).then(()=>{document.getElementById('pic_status').textContent='Saved device '+idx;loadPictures();});}"
        "function saveTracks(){const ok=document.getElementById('track_ok_select').value;const fail=document.getElementById('track_fail_select').value;fetch(`/api/pictures/tracks/save?ok=${encodeURIComponent(ok)}&fail=${encodeURIComponent(fail)}`).then(()=>{document.getElementById('pic_status').textContent='Tracks saved';setTimeout(()=>loadPictures(),200);});}"
        "function toggleAddMode(on){fetch(`/api/pictures/addmode?mode=${on?'on':'off'}`).then(()=>{document.getElementById('pic_status').textContent=on?'Add mode ON':'Add mode OFF';});}"
        "function forceCheck(){fetch('/api/pictures/scan').then(()=>new Promise(r=>setTimeout(r,300))).then(()=>fetch('/api/pictures/check')).then(r=>r.json()).then(res=>{document.getElementById('pic_status').textContent=res.ok?'OK':'FAIL';});}"
        "let laserEnabled=true;"
        "function updateLaserToggle(){const btn=document.getElementById('laser_toggle_btn');const st=document.getElementById('laser_toggle_status');if(btn){btn.textContent=laserEnabled?'Disable':'Enable';}if(st){st.textContent=laserEnabled?'Laser processing ON':'Laser processing OFF';st.style.color=laserEnabled?'#22c55e':'#f87171';}}"
        "function toggleLaser(){const next=!laserEnabled;fetch(`/api/laser/enable?state=${next?'on':'off'}`).then(r=>r.json()).then(j=>{laserEnabled=!!j.enabled;updateLaserToggle();}).catch(()=>{});}"
        "function saveLaser(){const hold=document.getElementById('laser_hold_select').value;const relay=document.getElementById('laser_relay_select').value;const sec=document.getElementById('laser_seconds').value||20;const mode=document.getElementById('laser_mode').value;const stat=document.getElementById('laser_status');fetch(`/api/laser/save?hold=${encodeURIComponent(hold)}&relay=${encodeURIComponent(relay)}&seconds=${encodeURIComponent(sec)}&mode=${encodeURIComponent(mode)}&enabled=${laserEnabled?'on':'off'}`).then(r=>r.text()).then(()=>{if(stat){stat.textContent='Saved';}});}"
 
        "function loadPictures(){return fetch('/api/pictures/config').then(r=>{if(!r.ok)throw new Error('pictures');return r.json();}).then(cfg=>{renderPicGrid(cfg);return cfg;}).catch(err=>{const s=document.getElementById('pic_status');if(s){s.textContent='Load failed';}throw err;});}"
        "function loadLaser(){return fetch('/api/laser/config').then(r=>{if(!r.ok)throw new Error('laser');return r.json();}).then(cfg=>{const hold=document.getElementById('laser_hold_select');const relay=document.getElementById('laser_relay_select');const sec=document.getElementById('laser_seconds');const mode=document.getElementById('laser_mode');const stat=document.getElementById('laser_status');if(hold&&cfg.hold){let ex=false;Array.from(hold.options||[]).forEach(o=>{if(o.value===cfg.hold)ex=true;});if(!ex){const opt=document.createElement('option');opt.value=cfg.hold;opt.textContent=cfg.hold.split('/').pop();hold.appendChild(opt);}hold.value=cfg.hold;}if(relay&&cfg.relay){let ex=false;Array.from(relay.options||[]).forEach(o=>{if(o.value===cfg.relay)ex=true;});if(!ex){const opt=document.createElement('option');opt.value=cfg.relay;opt.textContent=cfg.relay.split('/').pop();relay.appendChild(opt);}relay.value=cfg.relay;}if(sec&&cfg.seconds){sec.value=cfg.seconds;}if(mode&&cfg.mode){mode.value=cfg.mode;}laserEnabled=!!cfg.enabled;updateLaserToggle();if(stat){stat.textContent='Loaded';}return cfg;});}"
        "function assignFile(){const f=document.getElementById('audio_topic').value||'';const t=audio_topic.value;if(!f){alert('file?');return;}if(!t){alert('topic');return;}setFileStatus('Rules disabled in this build',true);}"
        "function fetchAudioStatus(){fetch('/api/status').then(r=>{if(!r.ok)throw new Error('HTTP '+r.status);return r.json();}).then(j=>{if(j.audio){updateAudioFromStatus(j.audio);}}).catch(()=>{});}"
        "function toggleRepeat(){repeatOne=!repeatOne;const btn=document.getElementById('audio_repeat_btn');if(btn){if(repeatOne){btn.classList.add('active');}else{btn.classList.remove('active');}}}"
        "refreshModeButtons();"
        "loadStatus();"
        "setInterval(fetchAudioStatus,1000);"
        "</script>"
        "</div>"
        "</body></html>";
    return send_ok(req, "text/html", page);
}

static esp_err_t start_httpd(void)
{
    if (s_server) {
        return ESP_OK;
    }
    httpd_config_t config = HTTPD_DEFAULT_CONFIG();
    config.server_port = 80;
    config.max_uri_handlers = 40; // many handlers registered
    config.max_open_sockets = 4;  // keep low to avoid netconn issues
    config.backlog_conn = 4;
    config.lru_purge_enable = false; // avoid extra socket churn
    config.keep_alive_enable = false; // close connections immediately
    config.stack_size = 12288; // avoid stack overflow with larger handlers/pages
    ESP_LOGI(TAG, "starting httpd: uri=%d sockets=%d backlog=%d keepalive=%d free_int=%u",
             config.max_uri_handlers, config.max_open_sockets, config.backlog_conn, config.keep_alive_enable,
             (unsigned)heap_caps_get_free_size(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT));
    esp_err_t err = httpd_start(&s_server, &config);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "httpd start failed: %s", esp_err_to_name(err));
        return err;
    }

    httpd_uri_t root = {.uri = "/", .method = HTTP_GET, .handler = root_get_handler};
    httpd_uri_t ping = {.uri = "/api/ping", .method = HTTP_GET, .handler = ping_handler};
    httpd_uri_t status = {.uri = "/api/status", .method = HTTP_GET, .handler = status_handler};
    httpd_uri_t wifi = {.uri = "/api/config/wifi", .method = HTTP_GET, .handler = wifi_config_handler};
    httpd_uri_t mqtt = {.uri = "/api/config/mqtt", .method = HTTP_GET, .handler = mqtt_config_handler};
    httpd_uri_t wifi_scan = {.uri = "/api/wifi/scan", .method = HTTP_GET, .handler = wifi_scan_handler};
    httpd_uri_t ap_stop = {.uri = "/api/ap/stop", .method = HTTP_GET, .handler = ap_stop_handler};
    httpd_uri_t play = {.uri = "/api/audio/play", .method = HTTP_GET, .handler = audio_play_handler};
    httpd_uri_t stop = {.uri = "/api/audio/stop", .method = HTTP_GET, .handler = audio_stop_handler};
    httpd_uri_t pause = {.uri = "/api/audio/pause", .method = HTTP_GET, .handler = audio_pause_handler};
    httpd_uri_t resume = {.uri = "/api/audio/resume", .method = HTTP_GET, .handler = audio_resume_handler};
    httpd_uri_t vol = {.uri = "/api/audio/volume", .method = HTTP_GET, .handler = audio_volume_handler};
    httpd_uri_t seek = {.uri = "/api/audio/seek", .method = HTTP_GET, .handler = audio_seek_handler};
    httpd_uri_t pub = {.uri = "/api/publish", .method = HTTP_GET, .handler = publish_handler};
    httpd_uri_t files = {.uri = "/api/files", .method = HTTP_GET, .handler = files_handler};
    httpd_uri_t pic_cfg = {.uri = "/api/pictures/config", .method = HTTP_GET, .handler = pictures_config_handler};
    httpd_uri_t pic_dev = {.uri = "/api/pictures/device/save", .method = HTTP_GET, .handler = pictures_device_save_handler};
    httpd_uri_t pic_tracks = {.uri = "/api/pictures/tracks/save", .method = HTTP_GET, .handler = pictures_tracks_save_handler};
    httpd_uri_t pic_addmode = {.uri = "/api/pictures/addmode", .method = HTTP_GET, .handler = pictures_addmode_handler};
    httpd_uri_t pic_scan  = {.uri = "/api/pictures/scan",        .method = HTTP_GET, .handler = pictures_scan_handler};
    httpd_uri_t pic_check = {.uri = "/api/pictures/check", .method = HTTP_GET, .handler = pictures_check_handler};    
    httpd_uri_t laser_cfg = {.uri = "/api/laser/config", .method = HTTP_GET, .handler = laser_config_handler};
    httpd_uri_t laser_save = {.uri = "/api/laser/save", .method = HTTP_GET, .handler = laser_save_handler};
    httpd_uri_t laser_enable = {.uri = "/api/laser/enable", .method = HTTP_GET, .handler = laser_enable_handler};
    httpd_uri_t robot_cfg = {.uri = "/api/robot/config", .method = HTTP_GET, .handler = robot_config_handler};
    httpd_uri_t robot_save = {.uri = "/api/robot/save", .method = HTTP_GET, .handler = robot_save_handler};
    httpd_uri_t robot_presets = {.uri = "/api/robot/presets", .method = HTTP_GET, .handler = robot_presets_get_handler};
    httpd_uri_t robot_preset_set = {.uri = "/api/robot/preset_set", .method = HTTP_GET, .handler = robot_presets_set_handler};
    httpd_uri_t robot_preset_play = {.uri = "/api/robot/preset_play", .method = HTTP_GET, .handler = robot_presets_play_handler};

    httpd_register_uri_handler(s_server, &root);
    httpd_register_uri_handler(s_server, &ping);
    httpd_register_uri_handler(s_server, &status);
    httpd_register_uri_handler(s_server, &wifi);
    httpd_register_uri_handler(s_server, &mqtt);
    httpd_register_uri_handler(s_server, &wifi_scan);
    httpd_register_uri_handler(s_server, &ap_stop);
    httpd_register_uri_handler(s_server, &play);
    httpd_register_uri_handler(s_server, &stop);
    httpd_register_uri_handler(s_server, &pause);
    httpd_register_uri_handler(s_server, &resume);
    httpd_register_uri_handler(s_server, &vol);
    httpd_register_uri_handler(s_server, &seek);
    httpd_register_uri_handler(s_server, &pub);
    httpd_register_uri_handler(s_server, &files);
    httpd_register_uri_handler(s_server, &pic_cfg);
    httpd_register_uri_handler(s_server, &pic_dev);
    httpd_register_uri_handler(s_server, &pic_tracks);
    httpd_register_uri_handler(s_server, &pic_addmode);
    httpd_register_uri_handler(s_server, &pic_scan);
    httpd_register_uri_handler(s_server, &pic_check);
    httpd_register_uri_handler(s_server, &laser_cfg);
    httpd_register_uri_handler(s_server, &laser_save);
    httpd_register_uri_handler(s_server, &laser_enable);
    httpd_register_uri_handler(s_server, &robot_cfg);
    httpd_register_uri_handler(s_server, &robot_save);
    httpd_register_uri_handler(s_server, &robot_presets);
    httpd_register_uri_handler(s_server, &robot_preset_set);
    httpd_register_uri_handler(s_server, &robot_preset_play);
    return ESP_OK;
}

esp_err_t web_ui_init(void)
{
    pic_load(&s_pic_cfg);
    laser_load(&s_laser_cfg);
    robot_load(&s_robot_cfg);
    robot_presets_load(&s_robot_presets);
    if (!s_pic_mutex) {
        s_pic_mutex = xSemaphoreCreateMutex();
    }
    if (!s_laser_mutex) {
        s_laser_mutex = xSemaphoreCreateMutex();
    }
    ESP_RETURN_ON_FALSE(s_pic_mutex && s_laser_mutex, ESP_ERR_NO_MEM, TAG, "mutex create failed");
    ESP_RETURN_ON_ERROR(event_bus_register_handler(on_event_bus), TAG, "event handler reg failed");
    return ESP_OK;
}

esp_err_t web_ui_start(void)
{
    ESP_RETURN_ON_ERROR(start_httpd(), TAG, "start httpd failed");
    ESP_LOGI(TAG, "web ui started on port 80");
    return ESP_OK;
}


